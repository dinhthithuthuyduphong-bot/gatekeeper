#!/bin/bash
set -uxo pipefail
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git checkout 4923d94fcb82aa74989193eb67d21f3c23e106a1 tests/mcp/test_mcp_connection_manager.py tests/test_app.py
git apply --verbose --reject - <<'EOF_114329324912'
diff --git a/tests/agents/test_agent_tasks_isolation.py b/tests/agents/test_agent_tasks_isolation.py
new file mode 100644
index 000000000..eeb63a01e
--- /dev/null
+++ b/tests/agents/test_agent_tasks_isolation.py
@@ -0,0 +1,22 @@
+import pytest
+
+from mcp_agent.core.context import initialize_context
+from mcp_agent.agents.agent import AgentTasks
+
+
+@pytest.mark.anyio
+async def test_agent_tasks_instance_scoped_state_isolation():
+    ctx = await initialize_context()
+
+    tasks_a = AgentTasks(context=ctx)
+    tasks_b = AgentTasks(context=ctx)
+
+    # They should not share aggregator dicts or locks
+    assert (
+        tasks_a.server_aggregators_for_agent is not tasks_b.server_aggregators_for_agent
+    )
+    assert (
+        tasks_a.server_aggregators_for_agent_lock
+        is not tasks_b.server_aggregators_for_agent_lock
+    )
+    assert tasks_a.agent_refcounts is not tasks_b.agent_refcounts
diff --git a/tests/integration/test_multithread_smoke.py b/tests/integration/test_multithread_smoke.py
new file mode 100644
index 000000000..08fd2d19b
--- /dev/null
+++ b/tests/integration/test_multithread_smoke.py
@@ -0,0 +1,74 @@
+import asyncio
+import concurrent.futures
+from unittest.mock import AsyncMock
+
+from mcp_agent.app import MCPApp
+from mcp_agent.agents.agent import Agent
+
+from mcp_agent.workflows.llm.augmented_llm import RequestParams, AugmentedLLM
+
+
+class _MockLLM(AugmentedLLM):
+    def __init__(self, agent=None, **kwargs):
+        super().__init__(**kwargs)
+        self.agent = agent
+        self.generate_mock = AsyncMock()
+        self.generate_str_mock = AsyncMock()
+        self.generate_structured_mock = AsyncMock()
+
+    async def generate(self, message, request_params=None):
+        return await self.generate_mock(message, request_params)
+
+    async def generate_str(self, message, request_params=None):
+        return await self.generate_str_mock(message, request_params)
+
+    async def generate_structured(self, message, response_model, request_params=None):
+        return await self.generate_structured_mock(
+            message, response_model, request_params
+        )
+
+
+class _MockLLMFactory:
+    def __call__(self, agent):
+        llm = _MockLLM(agent=agent)
+
+        async def _gen_str(message, request_params=None):
+            return "hello"
+
+        llm.generate_str_mock.side_effect = _gen_str
+        llm.generate_mock.side_effect = _gen_str
+        return llm
+
+
+def worker_once() -> str:
+    loop = asyncio.new_event_loop()
+    try:
+        asyncio.set_event_loop(loop)
+
+        async def run_once():
+            app = MCPApp(name="mt_smoke")
+            async with app.run():
+                agent = Agent(
+                    name="worker", instruction="You are concise.", server_names=[]
+                )
+                # Ensure agent uses this app's context (avoid global context across threads)
+                agent.context = app.context
+                await agent.attach_llm(llm_factory=_MockLLMFactory())
+                out = await agent.llm.generate_str(
+                    "Say hello",
+                    request_params=RequestParams(maxTokens=64, max_iterations=1),
+                )
+                return out
+
+        return loop.run_until_complete(run_once())
+    finally:
+        loop.close()
+        asyncio.set_event_loop(None)
+
+
+def test_multithread_smoke_two_workers():
+    # Run two workers concurrently; ensures independent event loops and app instances
+    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:
+        futures = [ex.submit(worker_once) for _ in range(2)]
+        results = [f.result(timeout=20) for f in futures]
+    assert all(isinstance(r, str) and len(r) > 0 for r in results)
diff --git a/tests/mcp/test_connection_manager_lifecycle.py b/tests/mcp/test_connection_manager_lifecycle.py
new file mode 100644
index 000000000..56df66a18
--- /dev/null
+++ b/tests/mcp/test_connection_manager_lifecycle.py
@@ -0,0 +1,21 @@
+import pytest
+
+from mcp_agent.mcp.mcp_connection_manager import MCPConnectionManager
+
+
+class DummyServerRegistry:
+    def __init__(self):
+        self.registry = {}
+        self.init_hooks = {}
+
+
+@pytest.mark.anyio
+async def test_connection_manager_lifecycle_single_loop():
+    mgr = MCPConnectionManager(server_registry=DummyServerRegistry())
+    # Enter context
+    await mgr.__aenter__()
+    # Disconnect (no servers) and exit
+    await mgr.disconnect_all()
+    await mgr.__aexit__(None, None, None)
+    # Should not raise and internal task group should be cleared
+    assert getattr(mgr, "_tg", None) is None
diff --git a/tests/mcp/test_mcp_connection_manager.py b/tests/mcp/test_mcp_connection_manager.py
index 72a0de7bb..8f0075ce2 100644
--- a/tests/mcp/test_mcp_connection_manager.py
+++ b/tests/mcp/test_mcp_connection_manager.py
@@ -158,7 +158,7 @@ async def test_disconnect_server(server_registry, dummy_client_session_factory):
         await server_conn.wait_for_initialized()
         await mgr.disconnect_server("srv1")
         await anyio.sleep(0)  # let event propagate
-        assert server_conn._shutdown_event.is_set()
+        assert server_conn._is_shutdown_requested_flag()
         assert "srv1" not in mgr.running_servers
 
 
@@ -175,8 +175,8 @@ async def test_disconnect_all(server_registry, dummy_client_session_factory):
         await conn2.wait_for_initialized()
         await mgr.disconnect_all()
         await anyio.sleep(0)
-        assert conn1._shutdown_event.is_set()
-        assert conn2._shutdown_event.is_set()
+        assert conn1._is_shutdown_requested_flag()
+        assert conn2._is_shutdown_requested_flag()
         assert mgr.running_servers == {}
 
 
diff --git a/tests/test_app.py b/tests/test_app.py
index 56f8eac01..677163457 100644
--- a/tests/test_app.py
+++ b/tests/test_app.py
@@ -72,8 +72,8 @@ async def run(self):
         return TestWorkflow
 
     @pytest.fixture
-    def test_task(self):
-        """Create a test task function."""
+    def test_task(self, request):
+        """Create a test task function with a unique name per test to avoid collisions."""
 
         async def task_function(param1: str, param2: int = 0):
             """A test task function.
@@ -87,6 +87,10 @@ async def task_function(param1: str, param2: int = 0):
             """
             return f"Task executed with {param1} and {param2}"
 
+        # Ensure a unique function identity to avoid activity name collisions across tests
+        task_function.__name__ = f"task_function_{request.node.name}"
+        task_function.__qualname__ = f"task_function_{request.node.name}"
+
         return task_function
 
     #

EOF_114329324912
: '>>>>> Start Test Output'
uv run pytest -rA
: '>>>>> End Test Output'
git checkout 4923d94fcb82aa74989193eb67d21f3c23e106a1 tests/mcp/test_mcp_connection_manager.py tests/test_app.py
