#!/bin/bash
set -uxo pipefail
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git checkout bc334e630cabc549f743161e1d68e5f975d9fd4d tests/v0_legacy/models/test_transformers_legacy.py tests/v0_legacy/models/test_transformers_vision_legacy.py
git apply --verbose --reject - <<'EOF_114329324912'
diff --git a/tests/v0_legacy/models/test_transformers_legacy.py b/tests/v0_legacy/models/test_transformers_legacy.py
index 2c34c2517..0388a4348 100644
--- a/tests/v0_legacy/models/test_transformers_legacy.py
+++ b/tests/v0_legacy/models/test_transformers_legacy.py
@@ -168,5 +168,6 @@ def test_transformers_legacy_call_generation():
         "foo",
         2,
         length_penalty=0.5,
+        tokenizer=model.tokenizer.tokenizer,
     )
     assert isinstance(result, str)
diff --git a/tests/v0_legacy/models/test_transformers_vision_legacy.py b/tests/v0_legacy/models/test_transformers_vision_legacy.py
index bcaf4ea3e..cd7324555 100644
--- a/tests/v0_legacy/models/test_transformers_vision_legacy.py
+++ b/tests/v0_legacy/models/test_transformers_vision_legacy.py
@@ -106,5 +106,6 @@ def test_transformers_vision_legacy_call_generation():
         "foo",
         2,
         length_penalty=0.5,
+        tokenizer=model.tokenizer.tokenizer,
     )
     assert isinstance(result, str)

EOF_114329324912
: '>>>>> Start Test Output'
pytest -rA
: '>>>>> End Test Output'
git checkout bc334e630cabc549f743161e1d68e5f975d9fd4d tests/v0_legacy/models/test_transformers_legacy.py tests/v0_legacy/models/test_transformers_vision_legacy.py
