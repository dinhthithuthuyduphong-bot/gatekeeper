#!/bin/bash
set -uxo pipefail
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git checkout 5398229da51147b24458d661a8c9820967ec5b10 scripts/functional-tests.sh tests/test_config.py
git apply --verbose --reject - <<'EOF_114329324912'
diff --git a/scripts/functional-tests.sh b/scripts/functional-tests.sh
index a0b8b5da5d..3f4047e482 100755
--- a/scripts/functional-tests.sh
+++ b/scripts/functional-tests.sh
@@ -135,8 +135,9 @@ ilab system sysinfo
 # pipe 3 carriage returns to ilab config init to get past the prompts
 echo -e "\n\n\n" | ilab init
 
-# Enable Debug in func tests
+# Enable Debug in func tests with debug level 1
 sed -i.bak -e 's/log_level:.*/log_level: DEBUG/g;' "${ILAB_CONFIG_FILE}"
+sed -i.bak -e 's/debug_level:.*/debug_level: 1/g;' "${ILAB_CONFIG_FILE}"
 
 # It looks like GitHub action MacOS runner does not have graphics
 # so we need to disable the GPU layers if we are running in GitHub actions
diff --git a/tests/test_config.py b/tests/test_config.py
index 2ed1ed7f56..5417bd5294 100644
--- a/tests/test_config.py
+++ b/tests/test_config.py
@@ -1,6 +1,7 @@
 # SPDX-License-Identifier: Apache-2.0
 
 # Standard
+import logging
 import os
 
 # Third Party
@@ -9,6 +10,7 @@
 
 # First Party
 from instructlab import configuration as config
+from instructlab.log import configure_logging
 
 
 class TestConfig:
@@ -27,6 +29,7 @@ def _assert_defaults(self, cfg: config.Config):
 
         assert cfg.general is not None
         assert cfg.general.log_level == "INFO"
+        assert cfg.general.debug_level == 0
 
         assert cfg.chat is not None
         assert cfg.chat.model == default_model
@@ -209,6 +212,8 @@ def test_config_modified_settings(self):
     max_workers: 5
   mt_bench_branch:
     taxonomy_path: taxonomy
+general:
+  log_level: DEBUG
 """
             )
         cfg = config.read_config(config_path)
@@ -221,3 +226,22 @@ def test_config_modified_settings(self):
             "--dtype=auto",
             "--enable-lora",
         ]
+        assert cfg.general.log_level == "DEBUG"
+        assert cfg.general.debug_level == 1
+
+
+@pytest.mark.parametrize(
+    "log_level,debug_level,root,instructlab,openai_httpx",
+    [
+        ("INFO", 0, logging.INFO, logging.INFO, logging.ERROR),
+        ("DEBUG", 1, logging.INFO, logging.DEBUG, logging.ERROR),
+        ("DEBUG", 2, logging.DEBUG, logging.DEBUG, logging.DEBUG),
+        ("ERROR", 0, logging.ERROR, logging.ERROR, logging.ERROR),
+    ],
+)
+def test_logging(log_level, debug_level, root, instructlab, openai_httpx):
+    configure_logging(log_level=log_level, debug_level=debug_level)
+    assert logging.getLogger("root").getEffectiveLevel() == root
+    assert logging.getLogger("instructlab").getEffectiveLevel() == instructlab
+    assert logging.getLogger("openai").getEffectiveLevel() == openai_httpx
+    assert logging.getLogger("httpx").getEffectiveLevel() == openai_httpx

EOF_114329324912
: '>>>>> Start Test Output'
pytest -rA
: '>>>>> End Test Output'
git checkout 5398229da51147b24458d661a8c9820967ec5b10 scripts/functional-tests.sh tests/test_config.py
