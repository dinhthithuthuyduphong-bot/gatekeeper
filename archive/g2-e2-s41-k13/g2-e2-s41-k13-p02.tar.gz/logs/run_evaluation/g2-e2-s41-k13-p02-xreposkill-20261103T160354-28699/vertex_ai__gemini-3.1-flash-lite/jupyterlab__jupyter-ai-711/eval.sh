#!/bin/bash
set -uxo pipefail
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git checkout 2acfd4db274a27da66f5e51316bafd1a941a8de7 packages/jupyter-ai/jupyter_ai/tests/__snapshots__/test_config_manager.ambr packages/jupyter-ai/jupyter_ai/tests/completions/test_handlers.py
git apply --verbose --reject - <<'EOF_114329324912'
diff --git a/packages/jupyter-ai/jupyter_ai/tests/__snapshots__/test_config_manager.ambr b/packages/jupyter-ai/jupyter_ai/tests/__snapshots__/test_config_manager.ambr
index cd254bedc..111ebe6ea 100644
--- a/packages/jupyter-ai/jupyter_ai/tests/__snapshots__/test_config_manager.ambr
+++ b/packages/jupyter-ai/jupyter_ai/tests/__snapshots__/test_config_manager.ambr
@@ -3,6 +3,9 @@
   dict({
     'api_keys': list([
     ]),
+    'completions_fields': dict({
+    }),
+    'completions_model_provider_id': None,
     'embeddings_provider_id': None,
     'fields': dict({
     }),
diff --git a/packages/jupyter-ai/jupyter_ai/tests/completions/test_handlers.py b/packages/jupyter-ai/jupyter_ai/tests/completions/test_handlers.py
index 8597463f2..c5b5d1eea 100644
--- a/packages/jupyter-ai/jupyter_ai/tests/completions/test_handlers.py
+++ b/packages/jupyter-ai/jupyter_ai/tests/completions/test_handlers.py
@@ -35,8 +35,8 @@ def __init__(self, lm_provider=None, lm_provider_params=None):
         self.messages = []
         self.tasks = []
         self.settings["jai_config_manager"] = SimpleNamespace(
-            lm_provider=lm_provider or MockProvider,
-            lm_provider_params=lm_provider_params or {"model_id": "model"},
+            completions_lm_provider=lm_provider or MockProvider,
+            completions_lm_provider_params=lm_provider_params or {"model_id": "model"},
         )
         self.settings["jai_event_loop"] = SimpleNamespace(
             create_task=lambda x: self.tasks.append(x)

EOF_114329324912
: '>>>>> Start Test Output'
pytest -vv -rA --cov jupyter_ai
: '>>>>> End Test Output'
git checkout 2acfd4db274a27da66f5e51316bafd1a941a8de7 packages/jupyter-ai/jupyter_ai/tests/__snapshots__/test_config_manager.ambr packages/jupyter-ai/jupyter_ai/tests/completions/test_handlers.py
