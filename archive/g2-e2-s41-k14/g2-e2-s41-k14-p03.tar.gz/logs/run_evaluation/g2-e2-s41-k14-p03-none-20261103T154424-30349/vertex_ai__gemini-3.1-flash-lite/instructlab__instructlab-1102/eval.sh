#!/bin/bash
set -uxo pipefail
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git checkout eadb214ef45a059d43e102942cc0d59046019a33 scripts/functional-tests.sh tests/test_config.py
git apply --verbose --reject - <<'EOF_114329324912'
diff --git a/scripts/functional-tests.sh b/scripts/functional-tests.sh
index 6e7e50c12f..ac4c3136f2 100755
--- a/scripts/functional-tests.sh
+++ b/scripts/functional-tests.sh
@@ -344,28 +344,12 @@ test_model_print(){
         }
     '
 
-    # validate that we print the model from the CLI
+    # validate that we fail on invalid model
     expect -c '
         set timeout 30
         spawn ilab chat -m bar
         expect {
-            -re "Welcome to InstructLab Chat w/ \\\u001b\\\[1mBAR\\\u001b\\\[0m" { exit 0 }
-            eof { catch wait result; exit [lindex $result 3] }
-            timeout { exit 1 }
-        }
-    '
-
-    # validate that we print the model from the config
-    expect -c '
-        exec sed -i.bak "s/merlinite-7b-lab-Q4_K_M/baz/g" config.yaml
-        spawn ilab chat
-        expect {
-            -re "Welcome to InstructLab Chat w/ \\\u001b\\\[1mBAZ\\\u001b\\\[0m" {
-                exec sed -i.bak "s/baz/merlinite-7b-lab-Q4_K_M/g" config.yaml
-                exit 0
-            }
-            eof { catch wait result; exit [lindex $result 3] }
-            timeout { exit 1 }
+           "Executing chat failed with: Model bar is not served by the server. These are the served models: ['models/foo.gguf']" { exit 0 }
         }
     '
 
diff --git a/tests/test_config.py b/tests/test_config.py
index b0cacd1b8c..053b19e27f 100644
--- a/tests/test_config.py
+++ b/tests/test_config.py
@@ -17,7 +17,7 @@ def _assert_defaults(self, cfg):
         assert cfg.general.log_level == "INFO"
 
         assert cfg.chat is not None
-        assert cfg.chat.model == "merlinite-7b-lab-Q4_K_M"
+        assert cfg.chat.model == "models/merlinite-7b-lab-Q4_K_M.gguf"
         assert not cfg.chat.vi_mode
         assert cfg.chat.visible_overflow
         assert cfg.chat.context == "default"
@@ -26,7 +26,7 @@ def _assert_defaults(self, cfg):
         assert not cfg.chat.greedy_mode
 
         assert cfg.generate is not None
-        assert cfg.generate.model == "merlinite-7b-lab-Q4_K_M"
+        assert cfg.generate.model == "models/merlinite-7b-lab-Q4_K_M.gguf"
         assert cfg.generate.taxonomy_path == "taxonomy"
         assert cfg.generate.taxonomy_base == "origin/main"
         assert cfg.generate.num_cpus == 10
@@ -52,9 +52,9 @@ def test_minimal_config(self):
         with open(config_path, "w", encoding="utf-8") as config_file:
             config_file.write(
                 """chat:
-  model: merlinite-7b-lab-Q4_K_M
+  model: models/merlinite-7b-lab-Q4_K_M.gguf
 generate:
-  model: merlinite-7b-lab-Q4_K_M
+  model: models/merlinite-7b-lab-Q4_K_M.gguf
   taxonomy_base: origin/main
   taxonomy_path: taxonomy
 serve:
@@ -75,12 +75,12 @@ def test_full_config(self):
   context: default
   greedy_mode: false
   logs_dir: data/chatlogs
-  model: merlinite-7b-lab-Q4_K_M
+  model: models/merlinite-7b-lab-Q4_K_M.gguf
   session: null
   vi_mode: false
   visible_overflow: true
 generate:
-  model: merlinite-7b-lab-Q4_K_M
+  model: models/merlinite-7b-lab-Q4_K_M.gguf
   num_cpus: 10
   num_instructions: 100
   output_dir: generated
@@ -106,9 +106,9 @@ def test_config_unexpected_fields(self):
         with open(config_path, "w", encoding="utf-8") as config_file:
             config_file.write(
                 """chat:
-  model: merlinite-7b-lab-Q4_K_M
+  model: models/merlinite-7b-lab-Q4_K_M.gguf
 generate:
-  model: merlinite-7b-lab-Q4_K_M
+  model: models/merlinite-7b-lab-Q4_K_M.gguf
   taxonomy_base: origin/main
   taxonomy_path: taxonomy
 serve:
@@ -145,7 +145,7 @@ def test_config_missing_required_fields(self):
                 """general:
   log_level: INFO
 generate:
-  model: merlinite-7b-lab-Q4_K_M
+  model: models/merlinite-7b-lab-Q4_K_M.gguf
 """
             )
         with pytest.raises(

EOF_114329324912
: '>>>>> Start Test Output'
pytest -rA
: '>>>>> End Test Output'
git checkout eadb214ef45a059d43e102942cc0d59046019a33 scripts/functional-tests.sh tests/test_config.py
