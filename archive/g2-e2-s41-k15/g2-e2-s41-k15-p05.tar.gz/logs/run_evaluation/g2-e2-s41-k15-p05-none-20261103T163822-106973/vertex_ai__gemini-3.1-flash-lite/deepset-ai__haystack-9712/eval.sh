#!/bin/bash
set -uxo pipefail
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git checkout 8bb8b67f8a353d86db92767bd407e27fd858792a test/core/pipeline/test_async_pipeline.py
git apply --verbose --reject - <<'EOF_114329324912'
diff --git a/test/core/pipeline/test_async_pipeline.py b/test/core/pipeline/test_async_pipeline.py
index 39afa3d6c9..a7b1612566 100644
--- a/test/core/pipeline/test_async_pipeline.py
+++ b/test/core/pipeline/test_async_pipeline.py
@@ -4,6 +4,8 @@
 
 import asyncio
 
+import pytest
+
 from haystack import AsyncPipeline
 
 
@@ -22,3 +24,22 @@ async def run_all():
     component_spans = [sp for sp in spying_tracer.spans if sp.operation_name == "haystack.component.run_async"]
     for span in component_spans:
         assert span.tags["haystack.component.visits"] == 1
+
+
+def test_run_in_sync_context(waiting_component):
+    pp = AsyncPipeline()
+    pp.add_component("wait", waiting_component())
+
+    result = pp.run({"wait_for": 0.001})
+
+    assert result == {"wait": {"waited_for": 0.001}}
+
+
+def test_run_in_async_context_raises_runtime_error():
+    pp = AsyncPipeline()
+
+    async def call_run():
+        pp.run({})
+
+    with pytest.raises(RuntimeError, match="Cannot call run\\(\\) from within an async context"):
+        asyncio.run(call_run())

EOF_114329324912
: '>>>>> Start Test Output'
hatch run test:unit -rA
: '>>>>> End Test Output'
git checkout 8bb8b67f8a353d86db92767bd407e27fd858792a test/core/pipeline/test_async_pipeline.py
