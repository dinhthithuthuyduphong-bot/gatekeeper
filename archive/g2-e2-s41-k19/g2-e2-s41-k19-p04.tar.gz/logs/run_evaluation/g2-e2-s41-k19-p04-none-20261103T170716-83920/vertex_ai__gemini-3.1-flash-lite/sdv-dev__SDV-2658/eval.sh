#!/bin/bash
set -uxo pipefail
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git checkout a400b4e963fb140290007835ff7e2872b9d330b9 tests/integration/cag/test_one_hot_encoding.py tests/unit/cag/test_one_hot_encoding.py
git apply --verbose --reject - <<'EOF_114329324912'
diff --git a/tests/integration/cag/test_one_hot_encoding.py b/tests/integration/cag/test_one_hot_encoding.py
index 5570d4499..5f100ea31 100644
--- a/tests/integration/cag/test_one_hot_encoding.py
+++ b/tests/integration/cag/test_one_hot_encoding.py
@@ -8,7 +8,7 @@
 from sdv.cag._errors import ConstraintNotMetError
 from sdv.metadata import Metadata
 from sdv.single_table import GaussianCopulaSynthesizer
-from tests.utils import run_copula, run_hma
+from tests.utils import run_constraint, run_copula, run_hma
 
 
 @pytest.fixture()
@@ -201,3 +201,144 @@ def test_end_to_end_boolean():
     assert (samples.sum(axis=1) == 1).all()
     for col in columns:
         assert sorted(samples[col].unique().tolist()) == [0, 1]
+
+
+def test_end_to_end_categorical_single(data, metadata):
+    """End-to-end with learning_strategy='categorical' for single-table data."""
+    # Setup
+    constraint = OneHotEncoding(column_names=['a', 'b', 'c'], learning_strategy='categorical')
+
+    # Run
+    synthesizer = run_copula(data, metadata, [constraint])
+    synthetic_data = synthesizer.sample(200)
+    synthesizer.validate_constraints(synthetic_data=synthetic_data)
+
+    # Assert
+    assert set(synthetic_data.columns) == {'a', 'b', 'c'}
+    for col in ['a', 'b', 'c']:
+        assert set(synthetic_data[col]) == {0, 1}
+    assert (synthetic_data[['a', 'b', 'c']].sum(axis=1) == 1).all()
+
+
+def test_end_to_end_categorical_single_raises(data, metadata):
+    """Invalid synthetic data should raise with learning_strategy='categorical'."""
+    # Setup
+    invalid_data = pd.DataFrame({
+        'a': [1, 2, 0],
+        'b': [0, 1, np.nan],
+        'c': [0, 0, 3],
+    })
+    constraint = OneHotEncoding(column_names=['a', 'b', 'c'], learning_strategy='categorical')
+
+    # Run and Assert
+    msg = re.escape(
+        "Data is not valid for the 'OneHotEncoding' constraint in table 'table':\n"
+        '   a    b  c\n'
+        '1  2  1.0  0\n'
+        '2  0  NaN  3'
+    )
+    with pytest.raises(ConstraintNotMetError, match=msg):
+        run_copula(invalid_data, metadata, [constraint])
+
+    # Run and Assert
+    msg = re.escape('The one hot encoding requirement is not met for row indices: 1, 2')
+    with pytest.raises(ConstraintNotMetError, match=msg):
+        synthesizer = run_copula(data, metadata, [constraint])
+        synthesizer.validate_constraints(synthetic_data=invalid_data)
+
+
+def test_end_to_end_categorical_multi(data_multi, metadata_multi):
+    """End-to-end with learning_strategy='categorical' for multi-table data."""
+    # Setup
+    constraint = OneHotEncoding(
+        column_names=['a', 'b', 'c'], table_name='table1', learning_strategy='categorical'
+    )
+
+    # Run
+    synthesizer = run_hma(data_multi, metadata_multi, [constraint])
+    synthetic = synthesizer.sample(200)
+    synthesizer.validate_constraints(synthetic_data=synthetic)
+
+    # Assert
+    assert set(synthetic['table1'].columns) == {'a', 'b', 'c'}
+    for col in ['a', 'b', 'c']:
+        assert set(synthetic['table1'][col]) == {0, 1}
+    assert (synthetic['table1'][['a', 'b', 'c']].sum(axis=1) == 1).all()
+
+
+def test_end_to_end_categorical_multi_raises(data_multi, metadata_multi):
+    """Invalid multi-table synthetic data should raise with learning_strategy='categorical'."""
+    # Setup
+    constraint = OneHotEncoding(
+        column_names=['a', 'b', 'c'], table_name='table1', learning_strategy='categorical'
+    )
+    invalid = {
+        'table1': pd.DataFrame({
+            'a': [1, 2, 0],
+            'b': [0, 1, np.nan],
+            'c': [0, 0, 3],
+        }),
+        'table2': pd.DataFrame({'id': range(5)}),
+    }
+
+    # Run and Assert
+    msg = re.escape(
+        "Data is not valid for the 'OneHotEncoding' constraint in table 'table1':\n   "
+        'a    b  c\n1  2  1.0  0\n2  0  NaN  3'
+    )
+    with pytest.raises(ConstraintNotMetError, match=msg):
+        run_hma(invalid, metadata_multi, [constraint])
+
+    # Run and Assert
+    msg = "Table 'table1': The one hot encoding requirement is not met for row indices: 1, 2."
+    with pytest.raises(ConstraintNotMetError, match=msg):
+        synthesizer = run_hma(data_multi, metadata_multi, [constraint])
+        synthesizer.validate_constraints(synthetic_data=invalid)
+
+
+def test_constraint_pipeline_categorical_single(data, metadata):
+    """Constraint pipeline behavior for categorical strategy (single table)."""
+    # Setup
+    constraint = OneHotEncoding(column_names=['a', 'b', 'c'], learning_strategy='categorical')
+
+    # Run
+    updated_metadata, transformed, reverse_transformed = run_constraint(constraint, data, metadata)
+
+    # Assert metadata
+    assert updated_metadata.get_column_names() == ['a#b#c']
+
+    # Assert transform
+    assert transformed.shape[1] == 1
+    assert not any(col in transformed.columns for col in ['a', 'b', 'c'])
+    assert set(transformed.columns) == {'a#b#c'}
+
+    # Assert reverse_transform
+    assert set(reverse_transformed.columns) == {'a', 'b', 'c'}
+    assert (reverse_transformed[['a', 'b', 'c']].sum(axis=1) == 1).all()
+    assert set(reverse_transformed.columns) == {'a', 'b', 'c'}
+
+
+def test_constraint_pipeline_categorical_multi(data_multi, metadata_multi):
+    """Constraint pipeline behavior for categorical strategy (multi table)."""
+    # Setup
+    orig_cols = ['a', 'b', 'c']
+    constraint = OneHotEncoding(
+        column_names=orig_cols, table_name='table1', learning_strategy='categorical'
+    )
+
+    # Run
+    updated_metadata, transformed, reverse_transformed = run_constraint(
+        constraint, data_multi, metadata_multi
+    )
+
+    # Assert metadata
+    assert updated_metadata.tables['table1'].get_column_names() == ['a#b#c']
+
+    # Assert transform
+    assert list(transformed['table1'].columns) != orig_cols
+    assert transformed['table1'].shape[1] == 1
+    assert list(transformed['table2'].columns) == list(data_multi['table2'].columns)
+
+    # Assert reverse_transform
+    assert set(reverse_transformed['table1'].columns) == set(orig_cols)
+    assert (reverse_transformed['table1'][orig_cols].sum(axis=1) == 1).all()
diff --git a/tests/unit/cag/test_one_hot_encoding.py b/tests/unit/cag/test_one_hot_encoding.py
index 3cdef6b08..17650aa2c 100644
--- a/tests/unit/cag/test_one_hot_encoding.py
+++ b/tests/unit/cag/test_one_hot_encoding.py
@@ -287,3 +287,136 @@ def test_is_valid(self):
         }
         for table, series in out.items():
             pd.testing.assert_series_equal(expected_out[table], series)
+
+    def test___init___invalid_learning_strategy(self):
+        """Test it raises if learning_strategy is invalid."""
+        # Run and Assert
+        err_msg = "`learning_strategy` must be either 'one_hot' or 'categorical'."
+        with pytest.raises(ValueError, match=err_msg):
+            OneHotEncoding(column_names=['a', 'b', 'c'], learning_strategy='bad')
+
+    def test_get_updated_metadata_categorical_single(self):
+        """Test updated metadata drops one-hot columns and adds a categorical column."""
+        # Setup
+        metadata = Metadata.load_from_dict({
+            'columns': {
+                'a': {'sdtype': 'numerical'},
+                'b': {'sdtype': 'numerical'},
+                'c': {'sdtype': 'numerical'},
+            }
+        })
+        instance = OneHotEncoding(column_names=['a', 'b', 'c'], learning_strategy='categorical')
+
+        # Run
+        updated = instance.get_updated_metadata(metadata)
+
+        # Assert
+        cols = updated.get_column_names()
+        assert cols == ['a#b#c']
+
+        table_name = updated._get_single_table_name()
+        assert updated.tables[table_name].columns[cols[0]]['sdtype'] == 'categorical'
+
+        assert 'a' not in cols
+        assert 'b' not in cols
+        assert 'c' not in cols
+
+    def test_get_updated_metadata_categorical_repeated_column_names(self):
+        """Test updated metadata drops one-hot columns and adds a categorical column."""
+        # Setup
+        metadata = Metadata.load_from_dict({
+            'columns': {
+                'a': {'sdtype': 'numerical'},
+                'b': {'sdtype': 'numerical'},
+                'c': {'sdtype': 'numerical'},
+                'a#b#c': {'sdtype': 'numerical'},
+            }
+        })
+        instance = OneHotEncoding(column_names=['a', 'b', 'c'], learning_strategy='categorical')
+
+        # Run
+        updated = instance.get_updated_metadata(metadata)
+
+        # Assert
+        cols = updated.get_column_names()
+        assert cols == ['a#b#c', 'a#b#c_']
+
+        table_name = updated._get_single_table_name()
+        assert updated.tables[table_name].columns[cols[0]]['sdtype'] == 'numerical'
+        assert updated.tables[table_name].columns[cols[1]]['sdtype'] == 'categorical'
+
+        assert 'a' not in cols
+        assert 'b' not in cols
+        assert 'c' not in cols
+
+    def test_transform_and_reverse_categorical_single(self):
+        """Test transform collapses to categorical and reverse restores one-hot (single table)."""
+        # Setup
+        data = pd.DataFrame({
+            'a': [1, 0, 0, 1],
+            'b': [0, 1, 0, 0],
+            'c': [0, 0, 1, 0],
+        })
+        metadata = Metadata.load_from_dict({
+            'columns': {
+                'a': {'sdtype': 'numerical'},
+                'b': {'sdtype': 'numerical'},
+                'c': {'sdtype': 'numerical'},
+            }
+        })
+        instance = OneHotEncoding(column_names=['a', 'b', 'c'], learning_strategy='categorical')
+
+        # Run
+        instance.fit(data, metadata)
+        transformed = instance.transform(data)
+        reversed_df = instance.reverse_transform(transformed)
+
+        # Assert
+        pd.testing.assert_frame_equal(transformed, pd.DataFrame({'a#b#c': ['a', 'b', 'c', 'a']}))
+        pd.testing.assert_frame_equal(data, reversed_df)
+
+    def test_transform_and_reverse_categorical_multi(self):
+        """Test transform/reverse with categorical strategy (multi table)."""
+        # Setup
+        data = {
+            'table1': pd.DataFrame({
+                'a': [1, 0, 0, 1],
+                'b': [0, 1, 0, 0],
+                'c': [0, 0, 1, 0],
+            }),
+            'table2': pd.DataFrame({'id': range(4)}),
+        }
+        metadata = Metadata.load_from_dict({
+            'tables': {
+                'table1': {
+                    'columns': {
+                        'a': {'sdtype': 'numerical'},
+                        'b': {'sdtype': 'numerical'},
+                        'c': {'sdtype': 'numerical'},
+                    }
+                },
+                'table2': {
+                    'columns': {
+                        'id': {'sdtype': 'id'},
+                    }
+                },
+            }
+        })
+        instance = OneHotEncoding(
+            column_names=['a', 'b', 'c'], table_name='table1', learning_strategy='categorical'
+        )
+
+        # Run
+        instance.fit(data, metadata)
+        transformed = instance.transform(data)
+        reversed_data = instance.reverse_transform(transformed)
+
+        # Assert
+        pd.testing.assert_frame_equal(
+            transformed['table1'], pd.DataFrame({'a#b#c': ['a', 'b', 'c', 'a']})
+        )
+        pd.testing.assert_frame_equal(data['table2'], transformed['table2'])
+
+        # Assert
+        pd.testing.assert_frame_equal(data['table1'], reversed_data['table1'])
+        pd.testing.assert_frame_equal(data['table2'], reversed_data['table2'])

EOF_114329324912
: '>>>>> Start Test Output'
cat tasks.py
python -m pytest ./tests/unit -rA
: '>>>>> End Test Output'
git checkout a400b4e963fb140290007835ff7e2872b9d330b9 tests/integration/cag/test_one_hot_encoding.py tests/unit/cag/test_one_hot_encoding.py
