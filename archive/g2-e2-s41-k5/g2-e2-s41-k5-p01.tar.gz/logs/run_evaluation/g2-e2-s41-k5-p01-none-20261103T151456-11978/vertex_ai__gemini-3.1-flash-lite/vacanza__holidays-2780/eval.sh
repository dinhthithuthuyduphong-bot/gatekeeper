#!/bin/bash
set -uxo pipefail
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git checkout ffbc1eb615e83d912dd917cde08cde484e279f0f tests/test_holiday_base.py
git apply --verbose --reject - <<'EOF_114329324912'
diff --git a/tests/test_holiday_base.py b/tests/test_holiday_base.py
index c191a86e81..b86a814d4a 100644
--- a/tests/test_holiday_base.py
+++ b/tests/test_holiday_base.py
@@ -696,6 +696,29 @@ def _populate(self, year):
         self.assertIn("2020-07-13", hb)
 
 
+class TestIsWeekend(unittest.TestCase):
+    def setUp(self):
+        self.hb = CountryStub1()
+
+    def test_is_weekend(self):
+        self.hb._populate(2022)
+
+        self.hb.weekend = {MON, TUE}
+        for dt in (date(2022, 10, 3), date(2022, 10, 4), "2022-10-03", "2022-10-04"):
+            self.assertTrue(self.hb.is_weekend(dt))
+
+        self.hb.weekend = set()
+        for dt in (date(2022, 10, 3), date(2022, 10, 4), "2022-10-03", "2022-10-04"):
+            self.assertFalse(self.hb.is_weekend(dt))
+
+        self.hb.weekend = {SAT, SUN}
+        for dt in (date(2022, 10, 1), date(2022, 10, 2), "2022-10-01", "2022-10-02"):
+            self.assertTrue(self.hb.is_weekend(dt))
+
+        for dt in (date(2022, 10, 3), date(2022, 10, 4), "2022-10-03", "2022-10-04"):
+            self.assertFalse(self.hb.is_weekend(dt))
+
+
 class TestKeyTransforms(unittest.TestCase):
     def setUp(self):
         self.hb = CountryStub1()

EOF_114329324912
: '>>>>> Start Test Output'
pytest --cov=. --cov-config=pyproject.toml --cov-report term-missing --cov-report xml --durations 10 --durations-min=0.75 --dist loadscope --no-cov-on-fail --numprocesses 4 -rA
: '>>>>> End Test Output'
git checkout ffbc1eb615e83d912dd917cde08cde484e279f0f tests/test_holiday_base.py
