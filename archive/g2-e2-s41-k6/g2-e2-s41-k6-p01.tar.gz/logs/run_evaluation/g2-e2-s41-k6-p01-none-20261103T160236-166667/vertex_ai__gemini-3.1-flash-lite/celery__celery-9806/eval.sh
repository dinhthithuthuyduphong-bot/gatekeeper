#!/bin/bash
set -uxo pipefail
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git checkout da4a80dc449301fde4355153b47af8c42caed37c t/smoke/tests/test_canvas.py t/unit/tasks/test_result.py
git apply --verbose --reject - <<'EOF_114329324912'
diff --git a/t/smoke/tests/test_canvas.py b/t/smoke/tests/test_canvas.py
index e0886d56e4..b6c69e7639 100644
--- a/t/smoke/tests/test_canvas.py
+++ b/t/smoke/tests/test_canvas.py
@@ -179,3 +179,15 @@ def test_chord_error_propagation_with_different_body_types(
         # The chord should fail with the expected exception from the failing task
         with pytest.raises(ExpectedException):
             result.get(timeout=RESULT_TIMEOUT)
+
+
+class test_complex_workflow:
+    def test_pending_tasks_released_on_forget(self, celery_setup: CeleryTestSetup):
+        sig = add.si(1, 1) | group(
+            add.s(1) | group(add.si(1, 1), add.si(2, 2)) | add.si(2, 2),
+            add.s(1) | group(add.si(1, 1), add.si(2, 2)) | add.si(2, 2)
+        ) | add.si(1, 1)
+        res = sig.apply_async(queue=celery_setup.worker.worker_queue)
+        assert not all(len(mapping) == 0 for mapping in res.backend._pending_results)
+        res.forget()
+        assert all(len(mapping) == 0 for mapping in res.backend._pending_results)
diff --git a/t/unit/tasks/test_result.py b/t/unit/tasks/test_result.py
index 062c069542..d5aaa48192 100644
--- a/t/unit/tasks/test_result.py
+++ b/t/unit/tasks/test_result.py
@@ -449,6 +449,20 @@ def test_date_done(self, utc_datetime_mock, timezone, date):
         result = Backend(app=self.app)._get_result_meta(None, states.SUCCESS, None, None)
         assert result.get('date_done') == date
 
+    def test_forget_remove_pending_result(self):
+        with patch('celery.result.AsyncResult.backend') as backend:
+            result = self.app.AsyncResult(self.task1['id'])
+            result.backend = backend
+            result_clone = copy.copy(result)
+            result.forget()
+            backend.remove_pending_result.assert_called_once_with(
+                result_clone
+            )
+
+        result = self.app.AsyncResult(self.task1['id'])
+        result.backend = None
+        del result
+
 
 class test_ResultSet:
 

EOF_114329324912
: '>>>>> Start Test Output'
pytest -rA -vv t/unit
pytest -rA -vv t/unit
: '>>>>> End Test Output'
git checkout da4a80dc449301fde4355153b47af8c42caed37c t/smoke/tests/test_canvas.py t/unit/tasks/test_result.py
