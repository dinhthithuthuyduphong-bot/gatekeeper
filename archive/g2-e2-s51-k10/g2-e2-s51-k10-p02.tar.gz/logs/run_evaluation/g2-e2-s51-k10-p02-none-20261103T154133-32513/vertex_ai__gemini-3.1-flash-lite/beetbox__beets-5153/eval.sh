#!/bin/bash
set -uxo pipefail
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git checkout b09806e0df8f01b9155017d3693764ae7beedcd5 beets/test/helper.py test/test_autotag.py test/test_mb.py
git apply --verbose --reject - <<'EOF_114329324912'
diff --git a/beets/test/helper.py b/beets/test/helper.py
index b12bfe7abc..9843b51e87 100644
--- a/beets/test/helper.py
+++ b/beets/test/helper.py
@@ -781,6 +781,7 @@ def generate_album_info(album_id, track_values):
     "albumtype",
     "va",
     "label",
+    "barcode",
     "artist_sort",
     "releasegroup_id",
     "catalognum",
diff --git a/test/test_autotag.py b/test/test_autotag.py
index 44c68ce9a1..6691348ed6 100644
--- a/test/test_autotag.py
+++ b/test/test_autotag.py
@@ -90,6 +90,7 @@ def test_current_metadata_likelies(self):
             "disctotal",
             "mb_albumid",
             "label",
+            "barcode",
             "catalognum",
             "country",
             "media",
diff --git a/test/test_mb.py b/test/test_mb.py
index 605d126f9e..5290b30212 100644
--- a/test/test_mb.py
+++ b/test/test_mb.py
@@ -69,6 +69,7 @@ def _make_release(
             },
             "country": "COUNTRY",
             "status": "STATUS",
+            "barcode": "BARCODE",
         }
 
         if multi_artist_credit:
@@ -379,6 +380,11 @@ def test_parse_status(self):
         d = mb.album_info(release)
         self.assertEqual(d.albumstatus, "STATUS")
 
+    def test_parse_barcode(self):
+        release = self._make_release(None)
+        d = mb.album_info(release)
+        self.assertEqual(d.barcode, "BARCODE")
+
     def test_parse_media(self):
         tracks = [
             self._make_track("TITLE ONE", "ID ONE", 100.0 * 1000.0),

EOF_114329324912
: '>>>>> Start Test Output'
pytest -rA
: '>>>>> End Test Output'
git checkout b09806e0df8f01b9155017d3693764ae7beedcd5 beets/test/helper.py test/test_autotag.py test/test_mb.py
