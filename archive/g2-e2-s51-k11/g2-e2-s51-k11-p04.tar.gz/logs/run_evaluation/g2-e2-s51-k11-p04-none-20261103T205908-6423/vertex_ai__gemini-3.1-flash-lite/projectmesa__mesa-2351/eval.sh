#!/bin/bash
set -uxo pipefail
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git checkout b0a36ecb1f7178aefd6c1c8ed86c53e56baa86c8 tests/test_agent.py
git apply --verbose --reject - <<'EOF_114329324912'
diff --git a/tests/test_agent.py b/tests/test_agent.py
index 70183ca07bc..b1ca0ba0eb7 100644
--- a/tests/test_agent.py
+++ b/tests/test_agent.py
@@ -170,6 +170,30 @@ def test_agent_rng():
     assert agent.rng is model.rng
 
 
+def test_agent_create():
+    """Test create agent factory method."""
+
+    class TestAgent(Agent):
+        def __init__(self, model, attr, def_attr, a=0, b=0):
+            super().__init__(model)
+            self.some_attribute = attr
+            self.some_default_value = def_attr
+            self.a = a
+            self.b = b
+
+    model = Model(seed=42)
+    n = 10
+    some_attribute = model.rng.random(n)
+    a = tuple([model.random.random() for _ in range(n)])
+    TestAgent.create_agents(model, n, some_attribute, 5, a=a, b=7)
+
+    for agent, value, a_i in zip(model.agents, some_attribute, a):
+        assert agent.some_attribute == value
+        assert agent.some_default_value == 5
+        assert agent.a == a_i
+        assert agent.b == 7
+
+
 def test_agent_add_remove_discard():
     """Test adding, removing and discarding agents from AgentSet."""
     model = Model()

EOF_114329324912
: '>>>>> Start Test Output'
pytest -rA
: '>>>>> End Test Output'
git checkout b0a36ecb1f7178aefd6c1c8ed86c53e56baa86c8 tests/test_agent.py
