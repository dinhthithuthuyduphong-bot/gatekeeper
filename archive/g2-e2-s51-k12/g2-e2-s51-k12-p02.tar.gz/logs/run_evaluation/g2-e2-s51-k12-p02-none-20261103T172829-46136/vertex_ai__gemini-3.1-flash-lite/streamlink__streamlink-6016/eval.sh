#!/bin/bash
set -uxo pipefail
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git checkout 6f78ab12df402b801628b4fa1b2071b0a7a01bb2 tests/plugins/test_twitch.py
git apply --verbose --reject - <<'EOF_114329324912'
diff --git a/tests/plugins/test_twitch.py b/tests/plugins/test_twitch.py
index 89ea494f900..1d2984a0525 100644
--- a/tests/plugins/test_twitch.py
+++ b/tests/plugins/test_twitch.py
@@ -341,12 +341,12 @@ def test_hls_low_latency_has_prefetch_disable_ads_no_preroll_with_prefetch_ads(s
         Seg, Pre = Segment, SegmentPrefetch
         ads = [
             Tag("EXT-X-DISCONTINUITY"),
-            TagDateRangeAd(start=DATETIME_BASE + timedelta(seconds=3), duration=4),
+            TagDateRangeAd(start=DATETIME_BASE + timedelta(seconds=2.5), duration=4),
         ]
         # noinspection PyTypeChecker
         segments = self.subject([
             # regular stream data with prefetch segments
-            Playlist(0, [Seg(0), Seg(1, duration=0.5), Pre(2), Pre(3)]),
+            Playlist(0, [Seg(0), Seg(1, duration=0.5), Pre(2), *ads, Pre(3)]),
             # three prefetch segments, one regular (2) and two ads (3 and 4)
             Playlist(1, [Seg(1, duration=0.5), Pre(2), *ads, Pre(3), Pre(4)]),
             # all prefetch segments are gone once regular prefetch segments have shifted
@@ -395,6 +395,33 @@ def test_hls_low_latency_no_ads_reload_time(self):
         self.await_read(read_all=True)
         assert self.thread.reader.worker.playlist_reload_time == pytest.approx(23 / 3)
 
+    @patch("streamlink.stream.hls.hls.log")
+    def test_hls_incorrect_discontinuity(self, mock_log):
+        discontinuity = Tag("EXT-X-DISCONTINUITY")
+        self.subject([
+            Playlist(0, [Segment(0), Segment(1), discontinuity, Segment(2), Segment(3)]),
+            Playlist(4, [Segment(4), discontinuity, Segment(5), Segment(6), Segment(7)], end=True),
+        ], streamoptions={"disable_ads": True, "low_latency": True})
+
+        self.await_write(6)
+        self.await_read(read_all=True)
+        assert mock_log.warning.mock_calls == []
+
+    @patch("streamlink.stream.hls.hls.log")
+    def test_hls_incorrect_discontinuity_prefetch(self, mock_log):
+        Seg, Pre = Segment, SegmentPrefetch
+        discontinuity = Tag("EXT-X-DISCONTINUITY")
+        tls = Tag("EXT-X-TWITCH-LIVE-SEQUENCE", 1234)  # value is irrelevant
+        self.subject([
+            Playlist(0, [Seg(0), Seg(1), discontinuity, tls, Pre(2), discontinuity, tls, Pre(3)]),
+            Playlist(1, [Seg(1), discontinuity, tls, Seg(2), discontinuity, tls, Pre(3), Pre(4)]),
+            Playlist(2, [Seg(2), discontinuity, tls, Seg(3), discontinuity, tls, Pre(4), Pre(5)], end=True),
+        ], streamoptions={"disable_ads": True, "low_latency": True})
+
+        self.await_write(4)
+        self.await_read(read_all=True)
+        assert mock_log.warning.mock_calls == []
+
 
 class TestTwitchAPIAccessToken:
     @pytest.fixture(autouse=True)

EOF_114329324912
: '>>>>> Start Test Output'
pytest -rA
: '>>>>> End Test Output'
git checkout 6f78ab12df402b801628b4fa1b2071b0a7a01bb2 tests/plugins/test_twitch.py
