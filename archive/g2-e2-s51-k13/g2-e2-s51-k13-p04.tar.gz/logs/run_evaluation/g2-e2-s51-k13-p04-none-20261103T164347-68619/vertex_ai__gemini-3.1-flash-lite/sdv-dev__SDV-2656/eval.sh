#!/bin/bash
set -uxo pipefail
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git checkout 33a19f9f55ca41eaf70582228209c259f860737e tests/unit/single_table/test_base.py
git apply --verbose --reject - <<'EOF_114329324912'
diff --git a/tests/unit/single_table/test_base.py b/tests/unit/single_table/test_base.py
index 1924cf7af..1f597cadb 100644
--- a/tests/unit/single_table/test_base.py
+++ b/tests/unit/single_table/test_base.py
@@ -2341,7 +2341,7 @@ def test__sample_with_conditions_constraints_not_met_backwards_compatability(sel
         conditions = pd.DataFrame({'name': ['Johanna', 'Doe'], 'salary': [100.0, 90.0]})
         instance = Mock()
         delattr(instance, '_chained_constraints')
-        instance._data_processor.transform.side_effect = [ConstraintsNotMetError]
+        instance._transform_conditions.side_effect = [ConstraintsNotMetError]
 
         # Run and Assert
         error_msg = 'Provided conditions are not valid for the given constraints.'
@@ -2407,6 +2407,17 @@ def test__sample_with_conditions_transformed_with_transformed_data(self):
             'keep_extra_columns': False,
         }
 
+    def test__transform_conditions(self):
+        # Setup
+        conditions = pd.DataFrame({'name': ['Johanna']})
+        instance = Mock()
+
+        # Run
+        BaseSingleTableSynthesizer._transform_conditions(instance, conditions)
+
+        # Assert
+        instance._data_processor.transform.assert_called_once_with(conditions, is_condition=True)
+
     def test__transform_conditions_chained_constraints_no_transformed_conditions(self):
         """Test when the conditions are not being transformed.
 
@@ -2417,7 +2428,7 @@ def test__transform_conditions_chained_constraints_no_transformed_conditions(sel
         conditions = pd.DataFrame({'name': ['Johanna']})
         instance = Mock()
         instance._validate_transform_constraints.side_effect = [KeyError]
-        instance._data_processor.transform.side_effect = [
+        instance._transform_conditions.side_effect = [
             pd.DataFrame(),
             pd.DataFrame(),
         ]

EOF_114329324912
: '>>>>> Start Test Output'
pytest -rA tests/unit
: '>>>>> End Test Output'
git checkout 33a19f9f55ca41eaf70582228209c259f860737e tests/unit/single_table/test_base.py
