#!/bin/bash
set -uxo pipefail
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git checkout 640f55a655f41b9d0216c3017b956a114118895a Tests/test_imagestat.py
git apply --verbose --reject - <<'EOF_114329324912'
diff --git a/Tests/test_imagestat.py b/Tests/test_imagestat.py
index 0dfbc5a2abb..0baab7ce21e 100644
--- a/Tests/test_imagestat.py
+++ b/Tests/test_imagestat.py
@@ -57,3 +57,13 @@ def test_constant() -> None:
     assert st.rms[0] == 128
     assert st.var[0] == 0
     assert st.stddev[0] == 0
+
+
+def test_zero_count() -> None:
+    im = Image.new("L", (0, 0))
+
+    st = ImageStat.Stat(im)
+
+    assert st.mean == [0]
+    assert st.rms == [0]
+    assert st.var == [0]

EOF_114329324912
: '>>>>> Start Test Output'
pytest -rA
: '>>>>> End Test Output'
git checkout 640f55a655f41b9d0216c3017b956a114118895a Tests/test_imagestat.py
