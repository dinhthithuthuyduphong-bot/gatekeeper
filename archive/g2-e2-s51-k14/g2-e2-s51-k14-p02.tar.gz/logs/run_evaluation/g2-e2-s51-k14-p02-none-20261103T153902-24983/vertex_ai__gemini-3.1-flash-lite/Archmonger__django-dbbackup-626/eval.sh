#!/bin/bash
set -uxo pipefail
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git checkout af665e759bbba078afef0366a47adc9521eec2f8 tests/test_connectors/test_base.py
git apply --verbose --reject - <<'EOF_114329324912'
diff --git a/tests/test_connectors/test_base.py b/tests/test_connectors/test_base.py
index 7a1917b0..4ace24e6 100644
--- a/tests/test_connectors/test_base.py
+++ b/tests/test_connectors/test_base.py
@@ -13,6 +13,21 @@ def test_get_connector(self):
         connector = get_connector()
         self.assertIsInstance(connector, BaseDBConnector)
     
+    def test_get_connector_sqlite_uses_backup_connector(self):
+        """Test that SQLite database uses SqliteBackupConnector as default."""
+        from unittest.mock import patch
+        from dbbackup.db.sqlite import SqliteBackupConnector
+        
+        # Mock the database connection to simulate SQLite
+        mock_connection = {
+            'ENGINE': 'django.db.backends.sqlite3'
+        }
+        
+        with patch('django.db.connections') as mock_connections:
+            mock_connections.__getitem__.return_value.settings_dict = mock_connection
+            connector = get_connector()
+            self.assertIsInstance(connector, SqliteBackupConnector)
+    
     def test_get_connector_oracle_fallback(self):
         """Test that Oracle database uses Django connector as fallback."""
         from unittest.mock import patch

EOF_114329324912
: '>>>>> Start Test Output'
hatch test -rA
hatch test -- -rA
: '>>>>> End Test Output'
git checkout af665e759bbba078afef0366a47adc9521eec2f8 tests/test_connectors/test_base.py
