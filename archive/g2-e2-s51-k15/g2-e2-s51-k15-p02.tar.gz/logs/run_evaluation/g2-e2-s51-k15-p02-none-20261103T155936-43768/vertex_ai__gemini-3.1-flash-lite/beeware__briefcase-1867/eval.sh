#!/bin/bash
set -uxo pipefail
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git checkout eeca2239384508506766faf1a541528ef688b290 tests/commands/new/test_build_context.py
git apply --verbose --reject - <<'EOF_114329324912'
diff --git a/tests/commands/new/test_build_context.py b/tests/commands/new/test_build_context.py
index ec86799a3..05cae9bd0 100644
--- a/tests/commands/new/test_build_context.py
+++ b/tests/commands/new/test_build_context.py
@@ -291,7 +291,6 @@ def test_question_sequence_console(new_command):
 def main():
     # Your app logic goes here
     print("Hello, World.")
-
 """,
         app_start_source="""\
 from {{ cookiecutter.module_name }}.app import main

EOF_114329324912
: '>>>>> Start Test Output'
pytest -rA
: '>>>>> End Test Output'
git checkout eeca2239384508506766faf1a541528ef688b290 tests/commands/new/test_build_context.py
