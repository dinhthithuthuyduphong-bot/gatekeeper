#!/bin/bash
set -uxo pipefail
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git checkout 251fe08f8da8214dafdf094afd80c543b8e2e0fe tests/plugins/test_tv3cat.py
git apply --verbose --reject - <<'EOF_114329324912'
diff --git a/tests/plugins/test_tv3cat.py b/tests/plugins/test_tv3cat.py
index cc6d386a4d1..6783d524e95 100644
--- a/tests/plugins/test_tv3cat.py
+++ b/tests/plugins/test_tv3cat.py
@@ -6,8 +6,22 @@ class TestPluginCanHandleUrlTV3Cat(PluginCanHandleUrl):
     __plugin__ = TV3Cat
 
     should_match_groups = [
-        ("https://ccma.cat/tv3/directe/tv3/", {"ident": "tv3"}),
-        ("https://ccma.cat/tv3/directe/324/", {"ident": "324"}),
-        ("https://www.ccma.cat/tv3/directe/tv3/", {"ident": "tv3"}),
-        ("https://www.ccma.cat/tv3/directe/324/", {"ident": "324"}),
+        (("live", "https://www.ccma.cat/3cat/directes/tv3/"), {"ident": "tv3"}),
+        (("live", "https://www.ccma.cat/3cat/directes/324/"), {"ident": "324"}),
+        (("live", "https://www.ccma.cat/3cat/directes/esport3/"), {"ident": "esport3"}),
+        (("live", "https://www.ccma.cat/3cat/directes/sx3/"), {"ident": "sx3"}),
+        (("live", "https://www.ccma.cat/3cat/directes/catalunya-radio/"), {"ident": "catalunya-radio"}),
+
+        (
+            ("vod", "https://www.ccma.cat/3cat/t1xc1-arribada/video/6260741/"),
+            {"ident": "6260741"},
+        ),
+        (
+            ("vod", "https://www.ccma.cat/3cat/merli-els-peripatetics-capitol-1/video/5549976/"),
+            {"ident": "5549976"},
+        ),
+        (
+            ("vod", "https://www.ccma.cat/3cat/buscant-la-sostenibilitat-i-la-tecnologia-del-futur/video/6268863/"),
+            {"ident": "6268863"},
+        ),
     ]

EOF_114329324912
: '>>>>> Start Test Output'
pytest -rA
: '>>>>> End Test Output'
git checkout 251fe08f8da8214dafdf094afd80c543b8e2e0fe tests/plugins/test_tv3cat.py
