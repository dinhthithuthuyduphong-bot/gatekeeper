#!/bin/bash
set -uxo pipefail
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git checkout ee56bb0edaac43d5b7113b2a9d00ed9723ae83b2 Tests/misc/visitor_test.py
git apply --verbose --reject - <<'EOF_114329324912'
diff --git a/Tests/misc/visitor_test.py b/Tests/misc/visitor_test.py
index 268cc716d7..eb1969ea86 100644
--- a/Tests/misc/visitor_test.py
+++ b/Tests/misc/visitor_test.py
@@ -24,6 +24,10 @@ def __init__(self):
         self.a = A()
 
 
+class C(B):
+    pass
+
+
 class TestVisitor(Visitor):
     def __init__(self):
         self.value = []
@@ -71,3 +75,9 @@ def test_visitor(self):
         visitor.defaultStop = True
         visitor.visit(b)
         assert visitor.value == ["B", "B a"]
+
+    def test_visitor_inheritance(self):
+        b = C()  # Should behave just like a B()
+        visitor = TestVisitor()
+        visitor.visit(b)
+        assert visitor.value == ["B", "B a", "A", 1, 2, 3, 5, 7, "e", E.E2, 10]

EOF_114329324912
: '>>>>> Start Test Output'
pytest -rA
: '>>>>> End Test Output'
git checkout ee56bb0edaac43d5b7113b2a9d00ed9723ae83b2 Tests/misc/visitor_test.py
