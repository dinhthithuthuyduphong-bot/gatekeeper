#!/bin/bash
set -uxo pipefail
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git checkout d53f97e984bfdd268aa92f8bf482ced0edda0110 pvlib/tests/test_spectrum.py pvlib/tests/test_tools.py
git apply --verbose --reject - <<'EOF_114329324912'
diff --git a/pvlib/tests/test_spectrum.py b/pvlib/tests/test_spectrum.py
index 793eaacfdf..7b86cb713e 100644
--- a/pvlib/tests/test_spectrum.py
+++ b/pvlib/tests/test_spectrum.py
@@ -140,7 +140,7 @@ def test_get_am15g():
 
 def test_calc_spectral_mismatch_field(spectrl2_data):
     # test that the mismatch is calculated correctly with
-    # - default and custom reference sepctrum
+    # - default and custom reference spectrum
     # - single or multiple sun spectra
 
     # sample data
@@ -315,3 +315,107 @@ def test_spectral_factor_caballero_supplied_ambiguous():
     with pytest.raises(ValueError):
         spectrum.spectral_factor_caballero(1, 1, 1, module_type=None,
                                            coefficients=None)
+
+
+@pytest.fixture
+def sr_and_eqe_fixture():
+    # Just some arbitrary data for testing the conversion functions
+    df = pd.DataFrame(
+        columns=("wavelength", "quantum_efficiency", "spectral_response"),
+        data=[
+            # nm, [0,1], A/W
+            [300, 0.85, 0.205671370402405],
+            [350, 0.86, 0.242772872514211],
+            [400, 0.87, 0.280680929019753],
+            [450, 0.88, 0.319395539919029],
+            [500, 0.89, 0.358916705212040],
+            [550, 0.90, 0.399244424898786],
+            [600, 0.91, 0.440378698979267],
+            [650, 0.92, 0.482319527453483],
+            [700, 0.93, 0.525066910321434],
+            [750, 0.94, 0.568620847583119],
+            [800, 0.95, 0.612981339238540],
+            [850, 0.90, 0.617014111207215],
+            [900, 0.80, 0.580719163489143],
+            [950, 0.70, 0.536358671833723],
+            [1000, 0.6, 0.483932636240953],
+            [1050, 0.4, 0.338752845368667],
+        ],
+    )
+    df.set_index("wavelength", inplace=True)
+    return df
+
+
+def test_sr_to_qe(sr_and_eqe_fixture):
+    # vector type
+    qe = spectrum.sr_to_qe(
+        sr_and_eqe_fixture["spectral_response"].values,
+        sr_and_eqe_fixture.index.values,  # wavelength, nm
+    )
+    assert_allclose(qe, sr_and_eqe_fixture["quantum_efficiency"])
+    # pandas series type
+    # note: output Series' name should match the input
+    qe = spectrum.sr_to_qe(
+        sr_and_eqe_fixture["spectral_response"]
+    )
+    pd.testing.assert_series_equal(
+        qe, sr_and_eqe_fixture["quantum_efficiency"],
+        check_names=False
+    )
+    assert qe.name == "spectral_response"
+    # series normalization
+    qe = spectrum.sr_to_qe(
+        sr_and_eqe_fixture["spectral_response"] * 10, normalize=True
+    )
+    pd.testing.assert_series_equal(
+        qe,
+        sr_and_eqe_fixture["quantum_efficiency"]
+        / max(sr_and_eqe_fixture["quantum_efficiency"]),
+        check_names=False,
+    )
+    # error on lack of wavelength parameter if no pandas object is provided
+    with pytest.raises(TypeError, match="must have an '.index' attribute"):
+        _ = spectrum.sr_to_qe(sr_and_eqe_fixture["spectral_response"].values)
+
+
+def test_qe_to_sr(sr_and_eqe_fixture):
+    # vector type
+    sr = spectrum.qe_to_sr(
+        sr_and_eqe_fixture["quantum_efficiency"].values,
+        sr_and_eqe_fixture.index.values,  # wavelength, nm
+    )
+    assert_allclose(sr, sr_and_eqe_fixture["spectral_response"])
+    # pandas series type
+    # note: output Series' name should match the input
+    sr = spectrum.qe_to_sr(
+        sr_and_eqe_fixture["quantum_efficiency"]
+    )
+    pd.testing.assert_series_equal(
+        sr, sr_and_eqe_fixture["spectral_response"],
+        check_names=False
+    )
+    assert sr.name == "quantum_efficiency"
+    # series normalization
+    sr = spectrum.qe_to_sr(
+        sr_and_eqe_fixture["quantum_efficiency"] * 10, normalize=True
+    )
+    pd.testing.assert_series_equal(
+        sr,
+        sr_and_eqe_fixture["spectral_response"]
+        / max(sr_and_eqe_fixture["spectral_response"]),
+        check_names=False,
+    )
+    # error on lack of wavelength parameter if no pandas object is provided
+    with pytest.raises(TypeError, match="must have an '.index' attribute"):
+        _ = spectrum.qe_to_sr(
+            sr_and_eqe_fixture["quantum_efficiency"].values
+        )
+
+
+def test_qe_and_sr_reciprocal_conversion(sr_and_eqe_fixture):
+    # test that the conversion functions are reciprocal
+    qe = spectrum.sr_to_qe(sr_and_eqe_fixture["spectral_response"])
+    sr = spectrum.qe_to_sr(qe)
+    assert_allclose(sr, sr_and_eqe_fixture["spectral_response"])
+    qe = spectrum.sr_to_qe(sr)
+    assert_allclose(qe, sr_and_eqe_fixture["quantum_efficiency"])
diff --git a/pvlib/tests/test_tools.py b/pvlib/tests/test_tools.py
index 583141a726..eb9e65c895 100644
--- a/pvlib/tests/test_tools.py
+++ b/pvlib/tests/test_tools.py
@@ -3,6 +3,7 @@
 from pvlib import tools
 import numpy as np
 import pandas as pd
+from numpy.testing import assert_allclose
 
 
 @pytest.mark.parametrize('keys, input_dict, expected', [
@@ -120,3 +121,26 @@ def test_get_pandas_index(args, args_idx):
         assert index is None
     else:
         pd.testing.assert_index_equal(args[args_idx].index, index)
+
+
+@pytest.mark.parametrize('data_in,expected', [
+    (np.array([1, 2, 3, 4, 5]),
+     np.array([0.2, 0.4, 0.6, 0.8, 1])),
+    (np.array([[0, 1, 2], [0, 3, 6]]),
+     np.array([[0, 0.5, 1], [0, 0.5, 1]])),
+    (pd.Series([1, 2, 3, 4, 5]),
+     pd.Series([0.2, 0.4, 0.6, 0.8, 1])),
+    (pd.DataFrame({"a": [0, 1, 2], "b": [0, 2, 8]}),
+     pd.DataFrame({"a": [0, 0.5, 1], "b": [0, 0.25, 1]})),
+    # test with NaN and all zeroes
+    (pd.DataFrame({"a": [0, np.nan, 1], "b": [0, 0, 0]}),
+     pd.DataFrame({"a": [0, np.nan, 1], "b": [np.nan]*3})),
+    # test with negative values
+    (np.array([1, 2, -3, 4, -5]),
+     np.array([0.2, 0.4, -0.6, 0.8, -1])),
+    (pd.Series([-2, np.nan, 1]),
+     pd.Series([-1, np.nan, 0.5])),
+])
+def test_normalize_max2one(data_in, expected):
+    result = tools.normalize_max2one(data_in)
+    assert_allclose(result, expected)

EOF_114329324912
: '>>>>> Start Test Output'
pytest pvlib --cov=./ --cov-report=xml --ignore=pvlib/tests/iotools -rA
: '>>>>> End Test Output'
git checkout d53f97e984bfdd268aa92f8bf482ced0edda0110 pvlib/tests/test_spectrum.py pvlib/tests/test_tools.py
