#!/bin/bash
set -uxo pipefail
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git checkout 75ddaffe4a2f4af6f83e840be9f456aa22a0104e smart_open/tests/test_smart_open.py
git apply --verbose --reject - <<'EOF_114329324912'
diff --git a/smart_open/tests/test_smart_open.py b/smart_open/tests/test_smart_open.py
index 414a9c64..e3727271 100644
--- a/smart_open/tests/test_smart_open.py
+++ b/smart_open/tests/test_smart_open.py
@@ -89,6 +89,18 @@ def test_zst_write():
     assert got == ["hello world\n", "this is a test\n"]
 
 
+def test_zst_write_binary():
+    with named_temporary_file(suffix=".zst") as tmp:
+        with smart_open.open(tmp.name, "wb") as fout:
+            fout.write(b"hello world\n")
+            fout.write(b"this is a test\n")
+
+        with smart_open.open(tmp.name, "rb") as fin:
+            got = list(fin)
+
+    assert got == [b"hello world\n", b"this is a test\n"]
+
+
 class ParseUriTest(unittest.TestCase):
     """
     Test ParseUri class.

EOF_114329324912
: '>>>>> Start Test Output'
pytest smart_open -v -rA
: '>>>>> End Test Output'
git checkout 75ddaffe4a2f4af6f83e840be9f456aa22a0104e smart_open/tests/test_smart_open.py
