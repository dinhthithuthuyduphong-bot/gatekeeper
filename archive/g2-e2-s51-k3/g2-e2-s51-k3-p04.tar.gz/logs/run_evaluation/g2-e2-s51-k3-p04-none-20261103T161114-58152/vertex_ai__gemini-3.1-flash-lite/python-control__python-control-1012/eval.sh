#!/bin/bash
set -uxo pipefail
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git checkout ad6b49e09034166ba972bbd5d3c080495f3b23b1 control/tests/statesp_test.py
git apply --verbose --reject - <<'EOF_114329324912'
diff --git a/control/tests/statesp_test.py b/control/tests/statesp_test.py
index 59f441456..6ddf9933e 100644
--- a/control/tests/statesp_test.py
+++ b/control/tests/statesp_test.py
@@ -463,28 +463,53 @@ def test_append_tf(self):
         np.testing.assert_array_almost_equal(sys3c.A[:3, 3:], np.zeros((3, 2)))
         np.testing.assert_array_almost_equal(sys3c.A[3:, :3], np.zeros((2, 3)))
 
-    def test_array_access_ss(self):
-
+    def test_array_access_ss_failure(self):
         sys1 = StateSpace(
             [[1., 2.], [3., 4.]],
             [[5., 6.], [6., 8.]],
             [[9., 10.], [11., 12.]],
             [[13., 14.], [15., 16.]], 1,
             inputs=['u0', 'u1'], outputs=['y0', 'y1'])
+        with pytest.raises(IOError):
+            sys1[0]
+
+    @pytest.mark.parametrize("outdx, inpdx", 
+                             [(0, 1),
+                              (slice(0, 1, 1), 1),
+                              (0, slice(1, 2, 1)),
+                              (slice(0, 1, 1), slice(1, 2, 1)),
+                              (slice(None, None, -1), 1),
+                              (0, slice(None, None, -1)),
+                              (slice(None, 2, None), 1),
+                              (slice(None, None, 1), slice(None, None, 2)),
+                              (0, slice(1, 2, 1)),
+                              (slice(0, 1, 1), slice(1, 2, 1))])
+    def test_array_access_ss(self, outdx, inpdx):
+        sys1 = StateSpace(
+            [[1., 2.], [3., 4.]],
+            [[5., 6.], [7., 8.]],
+            [[9., 10.], [11., 12.]],
+            [[13., 14.], [15., 16.]], 1,
+            inputs=['u0', 'u1'], outputs=['y0', 'y1'])
 
-        sys1_01 = sys1[0, 1]
+        sys1_01 = sys1[outdx, inpdx]
+        
+        # Convert int to slice to ensure that numpy doesn't drop the dimension
+        if isinstance(outdx, int): outdx = slice(outdx, outdx+1, 1)
+        if isinstance(inpdx, int): inpdx = slice(inpdx, inpdx+1, 1)
+        
         np.testing.assert_array_almost_equal(sys1_01.A,
                                              sys1.A)
         np.testing.assert_array_almost_equal(sys1_01.B,
-                                             sys1.B[:, 1:2])
+                                             sys1.B[:, inpdx])
         np.testing.assert_array_almost_equal(sys1_01.C,
-                                             sys1.C[0:1, :])
+                                             sys1.C[outdx, :])
         np.testing.assert_array_almost_equal(sys1_01.D,
-                                             sys1.D[0, 1])
+                                             sys1.D[outdx, inpdx])
 
         assert sys1.dt == sys1_01.dt
-        assert sys1_01.input_labels == ['u1']
-        assert sys1_01.output_labels == ['y0']
+        assert sys1_01.input_labels == sys1.input_labels[inpdx]
+        assert sys1_01.output_labels == sys1.output_labels[outdx]
         assert sys1_01.name == sys1.name + "$indexed"
 
     def test_dc_gain_cont(self):

EOF_114329324912
: '>>>>> Start Test Output'
pytest -rA
: '>>>>> End Test Output'
git checkout ad6b49e09034166ba972bbd5d3c080495f3b23b1 control/tests/statesp_test.py
