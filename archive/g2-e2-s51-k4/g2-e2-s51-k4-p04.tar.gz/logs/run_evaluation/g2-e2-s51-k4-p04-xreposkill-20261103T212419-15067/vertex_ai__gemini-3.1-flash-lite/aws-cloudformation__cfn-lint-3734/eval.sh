#!/bin/bash
set -uxo pipefail
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git checkout ced6ec369d3016dad69ef6f8a9ef41a484b3bdfb test/integration/test_integration_templates.py
git apply --verbose --reject - <<'EOF_114329324912'
diff --git a/test/fixtures/results/integration/aws-ec2-subnet.json b/test/fixtures/results/integration/aws-ec2-subnet.json
new file mode 100644
index 0000000000..616b6f34a2
--- /dev/null
+++ b/test/fixtures/results/integration/aws-ec2-subnet.json
@@ -0,0 +1,86 @@
+[
+    {
+        "Filename": "test/fixtures/templates/integration/aws-ec2-subnet.yaml",
+        "Id": "5c96f1f9-9dfc-31e7-f24b-9e08af46c98f",
+        "Level": "Error",
+        "Location": {
+            "End": {
+                "ColumnNumber": 15,
+                "LineNumber": 7
+            },
+            "Path": [
+                "Resources",
+                "Subnet1",
+                "Properties"
+            ],
+            "Start": {
+                "ColumnNumber": 5,
+                "LineNumber": 7
+            }
+        },
+        "Message": "'Ipv4IpamPoolId' is a dependency of 'Ipv4NetmaskLength'",
+        "ParentId": null,
+        "Rule": {
+            "Description": "When certain properties are specified it results in other properties to be required",
+            "Id": "E3021",
+            "ShortDescription": "Validate that when a property is specified that other properties should be included",
+            "Source": "https://github.com/aws-cloudformation/cfn-lint/blob/main/docs/cfn-schema-specification.md#dependentrequired"
+        }
+    },
+    {
+        "Filename": "test/fixtures/templates/integration/aws-ec2-subnet.yaml",
+        "Id": "5c12a390-4b88-f609-d6d6-bd7fa2250f99",
+        "Level": "Error",
+        "Location": {
+            "End": {
+                "ColumnNumber": 15,
+                "LineNumber": 13
+            },
+            "Path": [
+                "Resources",
+                "Subnet2",
+                "Properties"
+            ],
+            "Start": {
+                "ColumnNumber": 5,
+                "LineNumber": 13
+            }
+        },
+        "Message": "Only one of ['CidrBlock', 'Ipv4IpamPoolId'] is a required property",
+        "ParentId": null,
+        "Rule": {
+            "Description": "Make sure that Resources properties that are required exist. Along with other properties not being specified",
+            "Id": "E3014",
+            "ShortDescription": "Validate only one of a set of required properties are specified",
+            "Source": "https://github.com/aws-cloudformation/cfn-lint/blob/main/docs/cfn-schema-specification.md#requiredxor"
+        }
+    },
+    {
+        "Filename": "test/fixtures/templates/integration/aws-ec2-subnet.yaml",
+        "Id": "7a696880-e120-60b6-93b9-a57a48d71189",
+        "Level": "Error",
+        "Location": {
+            "End": {
+                "ColumnNumber": 15,
+                "LineNumber": 17
+            },
+            "Path": [
+                "Resources",
+                "Subnet3",
+                "Properties"
+            ],
+            "Start": {
+                "ColumnNumber": 5,
+                "LineNumber": 17
+            }
+        },
+        "Message": "'Ipv4NetmaskLength' is a dependency of 'Ipv4IpamPoolId'",
+        "ParentId": null,
+        "Rule": {
+            "Description": "When certain properties are specified it results in other properties to be required",
+            "Id": "E3021",
+            "ShortDescription": "Validate that when a property is specified that other properties should be included",
+            "Source": "https://github.com/aws-cloudformation/cfn-lint/blob/main/docs/cfn-schema-specification.md#dependentrequired"
+        }
+    }
+]
diff --git a/test/fixtures/templates/integration/aws-ec2-subnet.yaml b/test/fixtures/templates/integration/aws-ec2-subnet.yaml
new file mode 100644
index 0000000000..612fd56e64
--- /dev/null
+++ b/test/fixtures/templates/integration/aws-ec2-subnet.yaml
@@ -0,0 +1,19 @@
+Parameters:
+  Vpc:
+    Type: AWS::EC2::VPC::Id
+Resources:
+  Subnet1:
+    Type: AWS::EC2::Subnet
+    Properties:
+      VpcId: !Ref Vpc
+      CidrBlock: 10.0.0.0/24
+      Ipv4NetmaskLength: 10
+  Subnet2:
+    Type: AWS::EC2::Subnet
+    Properties:
+      VpcId: !Ref Vpc
+  Subnet3:
+    Type: AWS::EC2::Subnet
+    Properties:
+      VpcId: !Ref Vpc
+      Ipv4IpamPoolId: test
diff --git a/test/integration/test_integration_templates.py b/test/integration/test_integration_templates.py
index 761ff40f57..4b92d0d4a1 100644
--- a/test/integration/test_integration_templates.py
+++ b/test/integration/test_integration_templates.py
@@ -77,6 +77,13 @@ class TestQuickStartTemplates(BaseCliTestCase):
             ),
             "exit_code": 2,
         },
+        {
+            "filename": ("test/fixtures/templates/integration/aws-ec2-subnet.yaml"),
+            "results_filename": (
+                "test/fixtures/results/integration/aws-ec2-subnet.json"
+            ),
+            "exit_code": 2,
+        },
         {
             "filename": ("test/fixtures/templates/integration/aws-dynamodb-table.yaml"),
             "results_filename": (

EOF_114329324912
: '>>>>> Start Test Output'
pytest -rA
: '>>>>> End Test Output'
git checkout ced6ec369d3016dad69ef6f8a9ef41a484b3bdfb test/integration/test_integration_templates.py
