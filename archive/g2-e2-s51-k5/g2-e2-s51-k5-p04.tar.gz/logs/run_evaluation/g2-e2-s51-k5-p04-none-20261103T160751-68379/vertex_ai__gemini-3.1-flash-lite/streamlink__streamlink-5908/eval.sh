#!/bin/bash
set -uxo pipefail
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git checkout 33879e284c7987c81cce11b3ea06fd99533c395d tests/plugins/test_vkplay.py
git apply --verbose --reject - <<'EOF_114329324912'
diff --git a/tests/plugins/test_vkplay.py b/tests/plugins/test_vkplay.py
index d995ee8e328..3bb7377d1b1 100644
--- a/tests/plugins/test_vkplay.py
+++ b/tests/plugins/test_vkplay.py
@@ -6,10 +6,12 @@ class TestPluginCanHandleUrlVKplay(PluginCanHandleUrl):
     __plugin__ = VKplay
 
     should_match = [
-        "https://vkplay.live/Channel_Name_123",
+        "https://live.vkplay.ru/CHANNEL",
+        "https://vkplay.live/CHANNEL",
     ]
 
     should_not_match = [
+        "https://live.vkplay.ru/",
         "https://vkplay.live/",
         "https://support.vkplay.ru/vkp_live",
         "https://vkplay.live/app/settings/edit",

EOF_114329324912
: '>>>>> Start Test Output'
pytest -rA
: '>>>>> End Test Output'
git checkout 33879e284c7987c81cce11b3ea06fd99533c395d tests/plugins/test_vkplay.py
