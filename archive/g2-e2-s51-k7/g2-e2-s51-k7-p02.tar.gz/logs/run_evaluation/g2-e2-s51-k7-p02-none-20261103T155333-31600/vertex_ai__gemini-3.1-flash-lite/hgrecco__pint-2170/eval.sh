#!/bin/bash
set -uxo pipefail
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git checkout db0247017fd9bd2445db13b694d766880b7e3c20 pint/testsuite/test_definitions.py pint/testsuite/test_quantity.py
git apply --verbose --reject - <<'EOF_114329324912'
diff --git a/pint/testsuite/test_definitions.py b/pint/testsuite/test_definitions.py
index 56a107689..9df6df771 100644
--- a/pint/testsuite/test_definitions.py
+++ b/pint/testsuite/test_definitions.py
@@ -101,6 +101,25 @@ def test_unit_definition(self):
                 "degF = 9 / 5 * kelvin; offset: 255.372222 bla",
             )
 
+        x = Definition.from_string(f"meter_per_second_squared = acceleration")
+
+        assert isinstance(x, UnitDefinition)
+        assert x.name == "meter_per_second_squared"
+        assert x.aliases == ()
+        assert x.symbol == "meter_per_second_squared"
+        assert not x.is_base
+        assert isinstance(x.converter, ScaleConverter)
+        assert x.reference == UnitsContainer(acceleration=1)
+        x = Definition.from_string("kilometer_per_second = velocity")
+        assert isinstance(x, UnitDefinition)
+
+        assert x.name == "kilometer_per_second"
+        assert x.aliases == ()
+        assert x.symbol == "kilometer_per_second"
+        assert not x.is_base
+        assert isinstance(x.converter, ScaleConverter)
+        assert x.reference == UnitsContainer(velocity=1)
+
     def test_log_unit_definition(self):
         x = Definition.from_string(
             "decibelmilliwatt = 1e-3 watt; logbase: 10; logfactor: 10 = dBm"
diff --git a/pint/testsuite/test_quantity.py b/pint/testsuite/test_quantity.py
index 3bc6dce31..c676350dc 100644
--- a/pint/testsuite/test_quantity.py
+++ b/pint/testsuite/test_quantity.py
@@ -513,6 +513,8 @@ def test_context_attr(self):
     def test_both_symbol(self):
         assert self.Q_(2, "ms") == self.Q_(2, "millisecond")
         assert self.Q_(2, "cm") == self.Q_(2, "centimeter")
+        assert self.Q_(2, "mm / s ** 2") == self.Q_(
+            2, "millimeter_per_second_squared")
 
     def test_dimensionless_units(self):
         assert (

EOF_114329324912
: '>>>>> Start Test Output'
pytest -rA
: '>>>>> End Test Output'
git checkout db0247017fd9bd2445db13b694d766880b7e3c20 pint/testsuite/test_definitions.py pint/testsuite/test_quantity.py
