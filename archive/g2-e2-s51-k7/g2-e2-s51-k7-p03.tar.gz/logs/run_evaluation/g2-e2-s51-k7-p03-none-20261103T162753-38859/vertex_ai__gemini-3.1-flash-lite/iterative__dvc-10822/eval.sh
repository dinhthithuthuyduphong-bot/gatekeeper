#!/bin/bash
set -uxo pipefail
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git checkout fade6c599140253cef47b6e4ac97bdd8667a9e43 tests/func/test_data_status.py
git apply --verbose --reject - <<'EOF_114329324912'
diff --git a/tests/func/test_data_status.py b/tests/func/test_data_status.py
index fa3f2777a2..f45c53a8d1 100644
--- a/tests/func/test_data_status.py
+++ b/tests/func/test_data_status.py
@@ -918,3 +918,49 @@ def test_compat_legacy_new_cache_types(M, tmp_dir, dvc, scm):
         "committed": {"added": M.unordered("foo", "bar")},
         "git": M.dict(),
     }
+
+
+def test_missing_cache_remote_check(M, tmp_dir, dvc, scm, local_remote):
+    tmp_dir.dvc_gen({"dir": {"foo": "foo", "bar": "bar"}})
+    tmp_dir.dvc_gen("foobar", "foobar")
+    remove(dvc.cache.repo.path)
+
+    assert dvc.data_status(untracked_files="all", not_in_remote=True) == {
+        **EMPTY_STATUS,
+        "untracked": M.unordered("foobar.dvc", "dir.dvc", ".gitignore"),
+        "committed": {"added": M.unordered("foobar", join("dir", ""))},
+        "not_in_cache": M.unordered("foobar", join("dir", "")),
+        "git": M.dict(),
+        "not_in_remote": M.unordered("foobar", join("dir", "")),
+    }
+
+    assert dvc.data_status(
+        granular=True, untracked_files="all", not_in_remote=True
+    ) == {
+        **EMPTY_STATUS,
+        "untracked": M.unordered("foobar.dvc", "dir.dvc", ".gitignore"),
+        "committed": {"added": M.unordered("foobar", join("dir", ""))},
+        "uncommitted": {"unknown": M.unordered(join("dir", "foo"), join("dir", "bar"))},
+        "not_in_cache": M.unordered("foobar", join("dir", "")),
+        "git": M.dict(),
+        "not_in_remote": M.unordered("foobar", join("dir", "")),
+    }
+
+    assert dvc.data_status(["dir"], untracked_files="all", not_in_remote=True) == {
+        **EMPTY_STATUS,
+        "committed": {"added": [join("dir", "")]},
+        "not_in_cache": [join("dir", "")],
+        "git": M.dict(),
+        "not_in_remote": [join("dir", "")],
+    }
+
+    assert dvc.data_status(
+        ["dir"], untracked_files="all", not_in_remote=True, granular=True
+    ) == {
+        **EMPTY_STATUS,
+        "committed": {"added": [join("dir", "")]},
+        "uncommitted": {"unknown": M.unordered(join("dir", "foo"), join("dir", "bar"))},
+        "not_in_cache": [join("dir", "")],
+        "git": M.dict(),
+        "not_in_remote": [join("dir", "")],
+    }

EOF_114329324912
: '>>>>> Start Test Output'
pytest -rA
: '>>>>> End Test Output'
git checkout fade6c599140253cef47b6e4ac97bdd8667a9e43 tests/func/test_data_status.py
