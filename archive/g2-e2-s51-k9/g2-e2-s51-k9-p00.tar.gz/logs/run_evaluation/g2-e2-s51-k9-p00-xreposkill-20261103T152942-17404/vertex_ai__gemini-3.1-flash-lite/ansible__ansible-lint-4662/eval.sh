#!/bin/bash
set -uxo pipefail
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git checkout 4a73fdc2bda100a79b317aa9ab12715494e10658 .config/requirements-test.in test/test_rules_collection.py
git apply --verbose --reject - <<'EOF_114329324912'
diff --git a/.config/requirements-test.in b/.config/requirements-test.in
index f3c150f0ec..a958755a15 100644
--- a/.config/requirements-test.in
+++ b/.config/requirements-test.in
@@ -1,3 +1,4 @@
+ansible-creator >=24.6.0
 black # IDE support
 coverage-enable-subprocess # see https://github.com/nedbat/coveragepy/issues/1341#issuecomment-1228942657
 coverage[toml] >= 6.4.4
diff --git a/test/test_pattern.py b/test/test_pattern.py
new file mode 100644
index 0000000000..79fb34f948
--- /dev/null
+++ b/test/test_pattern.py
@@ -0,0 +1,53 @@
+"""Tests for the pattern feature."""
+
+import shutil
+import subprocess
+import sys
+import tempfile
+from pathlib import Path
+
+LINT_BIN = Path(sys.executable).parent / "ansible-lint"
+
+
+def test_creator_scaffolded_pattern() -> None:
+    """Validate creator scaffolded pattern.
+
+    Scaffold a pattern using ansible-creator. Run ansible-lint
+    on the scaffolded pattern and validate lint results.
+
+    Args:
+        monkeypatch: Monkeypatch fixture.
+    """
+    # Create a tmp dir and copy an existing collection into it
+    collection_src = Path("examples/collections/broken_no_runtime")
+    with tempfile.TemporaryDirectory() as tmpdir:
+        collection_dest = Path(tmpdir) / collection_src.name
+        shutil.copytree(collection_src, collection_dest)
+
+        # Scaffold a pattern using ansible-creator
+        result = subprocess.run(
+            [
+                "ansible-creator",
+                "add",
+                "resource",
+                "pattern",
+                "sample_pattern",
+                collection_dest,
+            ],
+            capture_output=True,
+            text=True,
+            check=False,
+        )
+        assert result.returncode == 0, f"Pattern scaffolding failed: {result.stderr}"
+
+        # Run ansible-lint on the scaffolded pattern
+        pattern_path = collection_dest
+
+        lint_result = subprocess.run(
+            [str(LINT_BIN), pattern_path],
+            capture_output=True,
+            text=True,
+            env={"NO_COLOR": "1"},
+            check=False,
+        )
+        assert lint_result.returncode == 0, f"ansible-lint failed: {lint_result.stderr}"
diff --git a/test/test_rules_collection.py b/test/test_rules_collection.py
index 7e3249052e..daf482caf1 100644
--- a/test/test_rules_collection.py
+++ b/test/test_rules_collection.py
@@ -173,5 +173,5 @@ def test_rules_id_format(config_options: Options) -> None:
             f"Rule {rule.id} must have at least one of:  .help, .description, .__doc__"
         )
     assert "yaml" in keys, "yaml rule is missing"
-    assert len(rules) == 51  # update this number when adding new rules!
+    assert len(rules) == 52  # update this number when adding new rules!
     assert len(keys) == len(rules), "Duplicate rule ids?"

EOF_114329324912
: '>>>>> Start Test Output'
pytest -rA
: '>>>>> End Test Output'
git checkout 4a73fdc2bda100a79b317aa9ab12715494e10658 .config/requirements-test.in test/test_rules_collection.py
