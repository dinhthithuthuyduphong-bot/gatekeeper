#!/bin/bash
set -uxo pipefail
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git checkout d0de78ec0ac45aca420a7b1c19f07cbc4bbb3f50 test/dataclasses/test_chat_message.py test/dataclasses/test_image_content.py test/utils/test_jinja2_chat_extension.py
git apply --verbose --reject - <<'EOF_114329324912'
diff --git a/test/dataclasses/test_chat_message.py b/test/dataclasses/test_chat_message.py
index 60f715e512..e978c7c0d3 100644
--- a/test/dataclasses/test_chat_message.py
+++ b/test/dataclasses/test_chat_message.py
@@ -10,6 +10,13 @@
 from haystack.dataclasses.image_content import ImageContent
 
 
+def test_chat_role_from_str():
+    assert ChatRole.from_str("user") == ChatRole.USER
+
+    with pytest.raises(ValueError):
+        ChatRole.from_str("invalid")
+
+
 def test_tool_call_init():
     tc = ToolCall(id="123", tool_name="mytool", arguments={"a": 1})
     assert tc.id == "123"
@@ -17,6 +24,18 @@ def test_tool_call_init():
     assert tc.arguments == {"a": 1}
 
 
+def test_tool_call_to_dict():
+    tc = ToolCall(id="123", tool_name="mytool", arguments={"a": 1})
+    assert tc.to_dict() == {"id": "123", "tool_name": "mytool", "arguments": {"a": 1}}
+
+
+def test_tool_call_from_dict():
+    tc = ToolCall.from_dict({"id": "123", "tool_name": "mytool", "arguments": {"a": 1}})
+    assert tc.id == "123"
+    assert tc.tool_name == "mytool"
+    assert tc.arguments == {"a": 1}
+
+
 def test_tool_call_result_init():
     tcr = ToolCallResult(result="result", origin=ToolCall(id="123", tool_name="mytool", arguments={"a": 1}), error=True)
     assert tcr.result == "result"
@@ -24,11 +43,42 @@ def test_tool_call_result_init():
     assert tcr.error
 
 
+def test_tool_call_result_to_dict():
+    tcr = ToolCallResult(result="result", origin=ToolCall(id="123", tool_name="mytool", arguments={"a": 1}), error=True)
+    assert tcr.to_dict() == {
+        "result": "result",
+        "origin": {"id": "123", "tool_name": "mytool", "arguments": {"a": 1}},
+        "error": True,
+    }
+
+
+def test_tool_call_result_from_dict():
+    tcr = ToolCallResult.from_dict(
+        {"result": "result", "origin": {"id": "123", "tool_name": "mytool", "arguments": {"a": 1}}, "error": True}
+    )
+    assert tcr.result == "result"
+    assert tcr.origin == ToolCall(id="123", tool_name="mytool", arguments={"a": 1})
+    assert tcr.error
+
+    with pytest.raises(ValueError):
+        ToolCallResult.from_dict({"result": "result", "error": False})
+
+
 def test_text_content_init():
     tc = TextContent(text="Hello")
     assert tc.text == "Hello"
 
 
+def test_text_content_to_dict():
+    tc = TextContent(text="Hello")
+    assert tc.to_dict() == {"text": "Hello"}
+
+
+def test_text_content_from_dict():
+    tc = TextContent.from_dict({"text": "Hello"})
+    assert tc.text == "Hello"
+
+
 def test_from_assistant_with_valid_content():
     text = "Hello, how can I assist you?"
     message = ChatMessage.from_assistant(text)
@@ -367,11 +417,6 @@ def test_chat_message_init_parameters_removed():
         ChatMessage(role="irrelevant", content="This is a message")
 
 
-def test_chat_message_init_content_parameter_type():
-    with pytest.raises(TypeError):
-        ChatMessage(ChatRole.USER, "This is a message")
-
-
 def test_to_openai_dict_format():
     message = ChatMessage.from_system("You are good assistant")
     assert message.to_openai_dict_format() == {"role": "system", "content": "You are good assistant"}
@@ -417,13 +462,16 @@ def test_to_openai_dict_format_user_message():
 
 def test_to_openai_dict_format_multimodal_user_message(base64_image_string):
     message = ChatMessage.from_user(
-        content_parts=[TextContent("I have a question"), ImageContent(base64_image=base64_image_string)]
+        content_parts=[TextContent("I have a question"), ImageContent(base64_image=base64_image_string, detail="auto")]
     )
     assert message.to_openai_dict_format() == {
         "role": "user",
         "content": [
             {"type": "text", "text": "I have a question"},
-            {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{base64_image_string}"}},
+            {
+                "type": "image_url",
+                "image_url": {"url": f"data:image/png;base64,{base64_image_string}", "detail": "auto"},
+            },
         ],
     }
 
diff --git a/test/dataclasses/test_image_content.py b/test/dataclasses/test_image_content.py
index 08bf3ebbc9..ff46157e3a 100644
--- a/test/dataclasses/test_image_content.py
+++ b/test/dataclasses/test_image_content.py
@@ -24,6 +24,36 @@ def test_image_content_init(base64_image_string):
     assert image_content.validation
 
 
+def test_image_content_to_dict(base64_image_string):
+    image_content = ImageContent(
+        base64_image=base64_image_string, mime_type="image/png", detail="auto", meta={"key": "value"}
+    )
+    assert image_content.to_dict() == {
+        "base64_image": base64_image_string,
+        "mime_type": "image/png",
+        "detail": "auto",
+        "meta": {"key": "value"},
+        "validation": True,
+    }
+
+
+def test_image_content_from_dict(base64_image_string):
+    image_content = ImageContent.from_dict(
+        {
+            "base64_image": base64_image_string,
+            "mime_type": "image/png",
+            "detail": "auto",
+            "meta": {"key": "value"},
+            "validation": False,
+        }
+    )
+    assert image_content.base64_image == base64_image_string
+    assert image_content.mime_type == "image/png"
+    assert image_content.detail == "auto"
+    assert image_content.meta == {"key": "value"}
+    assert not image_content.validation
+
+
 def test_image_content_init_with_invalid_base64_string():
     with pytest.raises(ValueError):
         ImageContent(base64_image="invalid_base64_string")
diff --git a/test/utils/test_jinja2_chat_extension.py b/test/utils/test_jinja2_chat_extension.py
index e4018e7b52..e83049002e 100644
--- a/test/utils/test_jinja2_chat_extension.py
+++ b/test/utils/test_jinja2_chat_extension.py
@@ -307,7 +307,7 @@ def test_invalid_role(self, jinja_env):
             jinja_env.from_string(template).render()
 
     def test_templatize_part_filter_with_invalid_type(self):
-        with pytest.raises(ValueError, match="Value must be an instance of one of the following types"):
+        with pytest.raises(TypeError, match="Unsupported type in ChatMessage content"):
             templatize_part(123)
 
     def test_empty_message_content_raises_error(self, jinja_env):
@@ -465,5 +465,5 @@ def test_invalid_tool_message_raises_error(self, jinja_env, base64_image_string)
         {{ image | templatize_part }}
         {% endmessage %}
         """
-        with pytest.raises(ValueError):
+        with pytest.raises(TypeError):
             jinja_env.from_string(template).render(image=image)

EOF_114329324912
: '>>>>> Start Test Output'
hatch run test:unit -- -rA
: '>>>>> End Test Output'
git checkout d0de78ec0ac45aca420a7b1c19f07cbc4bbb3f50 test/dataclasses/test_chat_message.py test/dataclasses/test_image_content.py test/utils/test_jinja2_chat_extension.py
