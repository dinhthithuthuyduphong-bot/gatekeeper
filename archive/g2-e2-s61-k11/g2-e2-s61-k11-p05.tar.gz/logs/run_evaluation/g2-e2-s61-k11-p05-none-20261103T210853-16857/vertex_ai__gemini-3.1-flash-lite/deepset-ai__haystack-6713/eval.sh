#!/bin/bash
set -uxo pipefail
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git checkout 1841aec11e479ed75d912bb01db7cc90dd2c4e47 test/components/generators/test_hugging_face_local_generator.py test/components/rankers/test_transformers_similarity.py test/components/readers/test_extractive.py
git apply --verbose --reject - <<'EOF_114329324912'
diff --git a/test/components/generators/test_hugging_face_local_generator.py b/test/components/generators/test_hugging_face_local_generator.py
index b83305c6b6..1e7bcf3061 100644
--- a/test/components/generators/test_hugging_face_local_generator.py
+++ b/test/components/generators/test_hugging_face_local_generator.py
@@ -153,6 +153,14 @@ def test_to_dict_with_parameters(self):
             token="test-token",
             generation_kwargs={"max_new_tokens": 100},
             stop_words=["coca", "cola"],
+            huggingface_pipeline_kwargs={
+                "model_kwargs": {
+                    "load_in_4bit": True,
+                    "bnb_4bit_use_double_quant": True,
+                    "bnb_4bit_quant_type": "nf4",
+                    "bnb_4bit_compute_dtype": torch.bfloat16,
+                }
+            },
         )
         data = component.to_dict()
 
@@ -162,14 +170,102 @@ def test_to_dict_with_parameters(self):
                 "huggingface_pipeline_kwargs": {
                     "model": "gpt2",
                     "task": "text-generation",
-                    "token": None,  # we don't want serialize valid tokens
                     "device": "cuda:0",
+                    "model_kwargs": {
+                        "load_in_4bit": True,
+                        "bnb_4bit_use_double_quant": True,
+                        "bnb_4bit_quant_type": "nf4",
+                        # dtype is correctly serialized
+                        "bnb_4bit_compute_dtype": "torch.bfloat16",
+                    },
                 },
                 "generation_kwargs": {"max_new_tokens": 100, "return_full_text": False},
                 "stop_words": ["coca", "cola"],
             },
         }
 
+    def test_to_dict_with_quantization_config(self):
+        component = HuggingFaceLocalGenerator(
+            model_name_or_path="gpt2",
+            task="text-generation",
+            device="cuda:0",
+            token="test-token",
+            generation_kwargs={"max_new_tokens": 100},
+            stop_words=["coca", "cola"],
+            huggingface_pipeline_kwargs={
+                "model_kwargs": {
+                    "quantization_config": {
+                        "load_in_4bit": True,
+                        "bnb_4bit_use_double_quant": True,
+                        "bnb_4bit_quant_type": "nf4",
+                        "bnb_4bit_compute_dtype": torch.bfloat16,
+                    }
+                }
+            },
+        )
+        data = component.to_dict()
+
+        assert data == {
+            "type": "haystack.components.generators.hugging_face_local.HuggingFaceLocalGenerator",
+            "init_parameters": {
+                "huggingface_pipeline_kwargs": {
+                    "model": "gpt2",
+                    "task": "text-generation",
+                    "device": "cuda:0",
+                    "model_kwargs": {
+                        "quantization_config": {
+                            "load_in_4bit": True,
+                            "bnb_4bit_use_double_quant": True,
+                            "bnb_4bit_quant_type": "nf4",
+                            # dtype is correctly serialized
+                            "bnb_4bit_compute_dtype": "torch.bfloat16",
+                        }
+                    },
+                },
+                "generation_kwargs": {"max_new_tokens": 100, "return_full_text": False},
+                "stop_words": ["coca", "cola"],
+            },
+        }
+
+    def test_from_dict(self):
+        data = {
+            "type": "haystack.components.generators.hugging_face_local.HuggingFaceLocalGenerator",
+            "init_parameters": {
+                "huggingface_pipeline_kwargs": {
+                    "model": "gpt2",
+                    "task": "text-generation",
+                    "device": "cuda:0",
+                    "model_kwargs": {
+                        "load_in_4bit": True,
+                        "bnb_4bit_use_double_quant": True,
+                        "bnb_4bit_quant_type": "nf4",
+                        # dtype is correctly serialized
+                        "bnb_4bit_compute_dtype": "torch.bfloat16",
+                    },
+                },
+                "generation_kwargs": {"max_new_tokens": 100, "return_full_text": False},
+                "stop_words": ["coca", "cola"],
+            },
+        }
+
+        component = HuggingFaceLocalGenerator.from_dict(data)
+
+        assert component.huggingface_pipeline_kwargs == {
+            "model": "gpt2",
+            "task": "text-generation",
+            "device": "cuda:0",
+            "token": None,
+            "model_kwargs": {
+                "load_in_4bit": True,
+                "bnb_4bit_use_double_quant": True,
+                "bnb_4bit_quant_type": "nf4",
+                # dtype is correctly deserialized
+                "bnb_4bit_compute_dtype": torch.bfloat16,
+            },
+        }
+        assert component.generation_kwargs == {"max_new_tokens": 100, "return_full_text": False}
+        assert component.stop_words == ["coca", "cola"]
+
     @patch("haystack.components.generators.hugging_face_local.pipeline")
     def test_warm_up(self, pipeline_mock):
         generator = HuggingFaceLocalGenerator(
diff --git a/test/components/rankers/test_transformers_similarity.py b/test/components/rankers/test_transformers_similarity.py
index 21566c4643..c81af7be53 100644
--- a/test/components/rankers/test_transformers_similarity.py
+++ b/test/components/rankers/test_transformers_similarity.py
@@ -36,7 +36,7 @@ def test_to_dict_with_custom_init_parameters(self):
             scale_score=False,
             calibration_factor=None,
             score_threshold=0.01,
-            model_kwargs={"torch_dtype": "auto"},
+            model_kwargs={"torch_dtype": torch.float16},
         )
         data = component.to_dict()
         assert data == {
@@ -51,10 +51,71 @@ def test_to_dict_with_custom_init_parameters(self):
                 "scale_score": False,
                 "calibration_factor": None,
                 "score_threshold": 0.01,
-                "model_kwargs": {"torch_dtype": "auto"},
+                "model_kwargs": {"torch_dtype": "torch.float16"},  # torch_dtype is correctly serialized
             },
         }
 
+    def test_to_dict_with_quantization_options(self):
+        component = TransformersSimilarityRanker(
+            model_kwargs={
+                "load_in_4bit": True,
+                "bnb_4bit_use_double_quant": True,
+                "bnb_4bit_quant_type": "nf4",
+                "bnb_4bit_compute_dtype": torch.bfloat16,
+            }
+        )
+        data = component.to_dict()
+        assert data == {
+            "type": "haystack.components.rankers.transformers_similarity.TransformersSimilarityRanker",
+            "init_parameters": {
+                "device": "cpu",
+                "top_k": 10,
+                "token": None,
+                "model_name_or_path": "cross-encoder/ms-marco-MiniLM-L-6-v2",
+                "meta_fields_to_embed": [],
+                "embedding_separator": "\n",
+                "scale_score": True,
+                "calibration_factor": 1.0,
+                "score_threshold": None,
+                "model_kwargs": {
+                    "load_in_4bit": True,
+                    "bnb_4bit_use_double_quant": True,
+                    "bnb_4bit_quant_type": "nf4",
+                    "bnb_4bit_compute_dtype": "torch.bfloat16",
+                },
+            },
+        }
+
+    def test_from_dict(self):
+        data = {
+            "type": "haystack.components.rankers.transformers_similarity.TransformersSimilarityRanker",
+            "init_parameters": {
+                "device": "cuda",
+                "model_name_or_path": "my_model",
+                "token": None,
+                "top_k": 5,
+                "meta_fields_to_embed": [],
+                "embedding_separator": "\n",
+                "scale_score": False,
+                "calibration_factor": None,
+                "score_threshold": 0.01,
+                "model_kwargs": {"torch_dtype": "torch.float16"},
+            },
+        }
+
+        component = TransformersSimilarityRanker.from_dict(data)
+        assert component.device == "cuda"
+        assert component.model_name_or_path == "my_model"
+        assert component.token is None
+        assert component.top_k == 5
+        assert component.meta_fields_to_embed == []
+        assert component.embedding_separator == "\n"
+        assert not component.scale_score
+        assert component.calibration_factor is None
+        assert component.score_threshold == 0.01
+        # torch_dtype is correctly deserialized
+        assert component.model_kwargs == {"torch_dtype": torch.float16}
+
     @patch("torch.sigmoid")
     @patch("torch.sort")
     def test_embed_meta(self, mocked_sort, mocked_sigmoid):
diff --git a/test/components/readers/test_extractive.py b/test/components/readers/test_extractive.py
index 3a62c33ad5..5d193db36d 100644
--- a/test/components/readers/test_extractive.py
+++ b/test/components/readers/test_extractive.py
@@ -88,7 +88,7 @@ def forward(self, input_ids, attention_mask, *args, **kwargs):
 
 
 def test_to_dict():
-    component = ExtractiveReader("my-model", token="secret-token", model_kwargs={"torch_dtype": "auto"})
+    component = ExtractiveReader("my-model", token="secret-token", model_kwargs={"torch_dtype": torch.float16})
     data = component.to_dict()
 
     assert data == {
@@ -105,7 +105,7 @@ def test_to_dict():
             "answers_per_seq": None,
             "no_answer": True,
             "calibration_factor": 0.1,
-            "model_kwargs": {"torch_dtype": "auto"},
+            "model_kwargs": {"torch_dtype": "torch.float16"},  # torch_dtype is correctly serialized
         },
     }
 
@@ -133,6 +133,40 @@ def test_to_dict_empty_model_kwargs():
     }
 
 
+def test_from_dict():
+    data = {
+        "type": "haystack.components.readers.extractive.ExtractiveReader",
+        "init_parameters": {
+            "model_name_or_path": "my-model",
+            "device": None,
+            "token": None,
+            "top_k": 20,
+            "score_threshold": None,
+            "max_seq_length": 384,
+            "stride": 128,
+            "max_batch_size": None,
+            "answers_per_seq": None,
+            "no_answer": True,
+            "calibration_factor": 0.1,
+            "model_kwargs": {"torch_dtype": "torch.float16"},
+        },
+    }
+
+    component = ExtractiveReader.from_dict(data)
+    assert component.model_name_or_path == "my-model"
+    assert component.token is None
+    assert component.top_k == 20
+    assert component.score_threshold is None
+    assert component.max_seq_length == 384
+    assert component.stride == 128
+    assert component.max_batch_size is None
+    assert component.answers_per_seq is None
+    assert component.no_answer
+    assert component.calibration_factor == 0.1
+    # torch_dtype is correctly deserialized
+    assert component.model_kwargs == {"torch_dtype": torch.float16}
+
+
 def test_output(mock_reader: ExtractiveReader):
     answers = mock_reader.run(example_queries[0], example_documents[0], top_k=3)[
         "answers"

EOF_114329324912
: '>>>>> Start Test Output'
pytest --cov-report xml:coverage.xml --cov="haystack" -m "not integration" -rA test
: '>>>>> End Test Output'
git checkout 1841aec11e479ed75d912bb01db7cc90dd2c4e47 test/components/generators/test_hugging_face_local_generator.py test/components/rankers/test_transformers_similarity.py test/components/readers/test_extractive.py
