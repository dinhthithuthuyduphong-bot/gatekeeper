#!/bin/bash
set -uxo pipefail
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git checkout 16017609ea2765c4651dbc13b4743578363b641a pvlib/tests/test_modelchain.py
git apply --verbose --reject - <<'EOF_114329324912'
diff --git a/pvlib/tests/test_modelchain.py b/pvlib/tests/test_modelchain.py
index 0632d34212..72c349c8e6 100644
--- a/pvlib/tests/test_modelchain.py
+++ b/pvlib/tests/test_modelchain.py
@@ -1305,6 +1305,22 @@ def test_temperature_model_inconsistent(location, sapm_dc_snl_ac_system):
                    spectral_model='no_loss', temperature_model='pvsyst')
 
 
+def test_temperature_model_not_specified():
+    # GH 1759 -- ensure correct error is raised when temperature model params
+    # are specified on the PVSystem instead of the Arrays
+    location = Location(latitude=32.2, longitude=-110.9)
+    arrays = [pvsystem.Array(pvsystem.FixedMount(),
+                             module_parameters={'pdc0': 1, 'gamma_pdc': 0})]
+    system = pvsystem.PVSystem(arrays,
+                               temperature_model_parameters={'u0': 1, 'u1': 1},
+                               inverter_parameters={'pdc0': 1})
+    with pytest.raises(ValueError,
+                       match='could not infer temperature model '
+                             'from system.temperature_model_parameters'):
+        _ = ModelChain(system, location,
+                       aoi_model='no_loss', spectral_model='no_loss')
+
+
 def test_dc_model_user_func(pvwatts_dc_pvwatts_ac_system, location, weather,
                             mocker):
     m = mocker.spy(sys.modules[__name__], 'poadc')

EOF_114329324912
: '>>>>> Start Test Output'
pytest pvlib --ignore=pvlib/tests/iotools -rA
: '>>>>> End Test Output'
git checkout 16017609ea2765c4651dbc13b4743578363b641a pvlib/tests/test_modelchain.py
