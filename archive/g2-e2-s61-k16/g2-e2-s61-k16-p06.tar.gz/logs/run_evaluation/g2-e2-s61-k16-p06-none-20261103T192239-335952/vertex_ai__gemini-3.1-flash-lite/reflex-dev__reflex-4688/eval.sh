#!/bin/bash
set -uxo pipefail
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git checkout abc9038580a8b6318cd693b5d6b1af2b4138c404 tests/units/utils/test_utils.py
git apply --verbose --reject - <<'EOF_114329324912'
diff --git a/tests/units/utils/test_utils.py b/tests/units/utils/test_utils.py
index f8573111ce7..65e77f4a77d 100644
--- a/tests/units/utils/test_utils.py
+++ b/tests/units/utils/test_utils.py
@@ -122,13 +122,13 @@ def test_validate_invalid_bun_path(mocker):
     Args:
         mocker: Pytest mocker object.
     """
-    mock = mocker.Mock()
-    mocker.patch.object(mock, "bun_path", return_value="/mock/path")
-    mocker.patch("reflex.utils.prerequisites.get_config", mock)
+    mock_path = mocker.Mock()
+    mocker.patch("reflex.utils.path_ops.get_bun_path", return_value=mock_path)
     mocker.patch("reflex.utils.prerequisites.get_bun_version", return_value=None)
 
     with pytest.raises(typer.Exit):
         prerequisites.validate_bun()
+    mock_path.samefile.assert_called_once()
 
 
 def test_validate_bun_path_incompatible_version(mocker):
@@ -137,9 +137,8 @@ def test_validate_bun_path_incompatible_version(mocker):
     Args:
         mocker: Pytest mocker object.
     """
-    mock = mocker.Mock()
-    mocker.patch.object(mock, "bun_path", return_value="/mock/path")
-    mocker.patch("reflex.utils.prerequisites.get_config", mock)
+    mock_path = mocker.Mock()
+    mocker.patch("reflex.utils.path_ops.get_bun_path", return_value=mock_path)
     mocker.patch(
         "reflex.utils.prerequisites.get_bun_version",
         return_value=version.parse("0.6.5"),

EOF_114329324912
: '>>>>> Start Test Output'
poetry run pytest -rA tests/units --cov --no-cov-on-fail --cov-report=
: '>>>>> End Test Output'
git checkout abc9038580a8b6318cd693b5d6b1af2b4138c404 tests/units/utils/test_utils.py
