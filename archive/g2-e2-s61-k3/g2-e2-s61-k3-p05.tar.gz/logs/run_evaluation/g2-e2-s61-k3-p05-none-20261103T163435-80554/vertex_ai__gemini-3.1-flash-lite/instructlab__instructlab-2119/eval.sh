#!/bin/bash
set -uxo pipefail
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git checkout 9be662aacc994c7016e9c0724500c658589369f2 tests/test_lab_evaluate.py
git apply --verbose --reject - <<'EOF_114329324912'
diff --git a/tests/test_lab_evaluate.py b/tests/test_lab_evaluate.py
index c0ab028f90..24aee9440f 100644
--- a/tests/test_lab_evaluate.py
+++ b/tests/test_lab_evaluate.py
@@ -661,3 +661,26 @@ def test_vllm_args_null(_, cli_runner: CliRunner):
         ],
     )
     common.assert_tps(args, "4")
+
+
+@patch("instructlab.model.evaluate.validate_model")
+def test_no_gpu_warning(validate_model_mock, cli_runner: CliRunner):
+    result = cli_runner.invoke(
+        lab.ilab,
+        [
+            "--config=DEFAULT",
+            "model",
+            "evaluate",
+            "--benchmark",
+            "mmlu",
+            "--model",
+            "instructlab/granite-7b-lab",
+            "--backend",
+            "vllm",
+        ],
+    )
+    validate_model_mock.assert_called_once()
+    assert (
+        "Evaluate is currently not configured to use GPUs. If you are on a GPU-enabled system edit your config or pass the number of GPUs you would like to use with '--gpus'"
+        in result.output
+    )

EOF_114329324912
: '>>>>> Start Test Output'
pytest -rA
: '>>>>> End Test Output'
git checkout 9be662aacc994c7016e9c0724500c658589369f2 tests/test_lab_evaluate.py
