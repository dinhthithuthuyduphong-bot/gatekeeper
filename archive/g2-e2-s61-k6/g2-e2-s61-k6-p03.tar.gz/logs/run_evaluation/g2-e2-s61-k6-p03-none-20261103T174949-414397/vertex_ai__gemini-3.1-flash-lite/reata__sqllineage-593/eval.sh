#!/bin/bash
set -uxo pipefail
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git checkout 55bbdb8da2fe0d46412dbcbfcf3d8787980027c0 tests/core/test_parser.py tests/sql/table/test_select.py
git apply --verbose --reject - <<'EOF_114329324912'
diff --git a/tests/core/test_parser.py b/tests/core/test_parser.py
index 777317ca..b24b9c15 100644
--- a/tests/core/test_parser.py
+++ b/tests/core/test_parser.py
@@ -1,9 +1,17 @@
 from unittest.mock import Mock
 
+from sqlfluff.core import Linter
+
 from sqllineage.core.parser.sqlfluff.models import SqlFluffColumn
+from sqllineage.core.parser.sqlfluff.utils import find_from_expression_element
 
 
 def test_column_extract_source_columns():
     segment_mock = Mock()
     segment_mock.type = ""
     assert [] == SqlFluffColumn._extract_source_columns(segment_mock)
+
+
+def test_return_none_find_from_expression_element():
+    file_segment = Linter(dialect="ansi").parse_string("TRUNCATE TABLE tab").tree
+    assert find_from_expression_element(file_segment) is None
diff --git a/tests/sql/table/test_select.py b/tests/sql/table/test_select.py
index ae70a270..fe143dcc 100644
--- a/tests/sql/table/test_select.py
+++ b/tests/sql/table/test_select.py
@@ -107,8 +107,33 @@ def test_select_parenthesized_from_table_join_recursive():
     sql = """SELECT tab1.id
 FROM ((tab1
     LEFT JOIN tab2 ON tab1.id = tab2.id)
-    LEFT JOIN tab3 ON tab1.id = tab3.id)"""
+    LEFT JOIN tab3 ON tab1.id = tab3.id)
+    """
     assert_table_lineage_equal(sql, {"tab1", "tab2", "tab3"})
+    sql = """SELECT tab1.id
+FROM (((tab1
+    LEFT JOIN tab2 ON tab1.id = tab2.id)
+    LEFT JOIN tab3 ON tab1.id = tab3.id)
+    LEFT JOIN tab4 ON tab1.id = tab4.id)
+    """
+    assert_table_lineage_equal(sql, {"tab1", "tab2", "tab3", "tab4"})
+    sql = """SELECT tab1.id
+FROM ((((tab1
+    LEFT JOIN tab2 ON tab1.id = tab2.id)
+    LEFT JOIN tab3 ON tab1.id = tab3.id)
+    LEFT JOIN tab4 ON tab1.id = tab4.id)
+    LEFT JOIN tab5 ON tab1.id = tab5.id)
+    """
+    assert_table_lineage_equal(sql, {"tab1", "tab2", "tab3", "tab4", "tab5"})
+    sql = """SELECT tab1.id
+FROM (((((tab1
+    LEFT JOIN tab2 ON tab1.id = tab2.id)
+    LEFT JOIN tab3 ON tab1.id = tab3.id)
+    LEFT JOIN tab4 ON tab1.id = tab4.id)
+    LEFT JOIN tab5 ON tab1.id = tab5.id)
+    LEFT JOIN tab6 ON tab1.id = tab6.id)
+        """
+    assert_table_lineage_equal(sql, {"tab1", "tab2", "tab3", "tab4", "tab5", "tab6"})
 
 
 def test_select_subquery():

EOF_114329324912
: '>>>>> Start Test Output'
pytest -rA
: '>>>>> End Test Output'
git checkout 55bbdb8da2fe0d46412dbcbfcf3d8787980027c0 tests/core/test_parser.py tests/sql/table/test_select.py
