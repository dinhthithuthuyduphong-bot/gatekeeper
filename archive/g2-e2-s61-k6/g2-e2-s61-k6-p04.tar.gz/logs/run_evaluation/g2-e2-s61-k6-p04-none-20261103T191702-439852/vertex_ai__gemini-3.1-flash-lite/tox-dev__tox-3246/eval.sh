#!/bin/bash
set -uxo pipefail
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git checkout 380d2e21c08df30034372cd31f445f3da1f48cef tests/test_provision.py tests/tox_env/python/test_python_api.py
git apply --verbose --reject - <<'EOF_114329324912'
diff --git a/tests/test_provision.py b/tests/test_provision.py
index 3b5bd197e..41eb630e0 100644
--- a/tests/test_provision.py
+++ b/tests/test_provision.py
@@ -229,3 +229,19 @@ def test_provision_conf_file(tox_project: ToxProjectCreator, tmp_path: Path, rel
     conf_path = str(Path(project.path.name) / "tox.ini") if relative_path else str(project.path / "tox.ini")
     result = project.run("c", "--conf", conf_path, "-e", "py", from_cwd=tmp_path)
     result.assert_success()
+
+
+@pytest.mark.parametrize("subcommand", ["r", "p", "de", "l", "d", "c", "q", "e", "le"])
+def test_provision_default_arguments_exists(tox_project: ToxProjectCreator, subcommand: str) -> None:
+    ini = r"""
+    [tox]
+    requires =
+        tox<4.14
+    [testenv]
+    package = skip
+    """
+    project = tox_project({"tox.ini": ini})
+    project.patch_execute(lambda r: 0 if "install" in r.run_id else None)
+    outcome = project.run(subcommand)
+    for argument in ["result_json", "hash_seed", "discover", "list_dependencies"]:
+        assert hasattr(outcome.state.conf.options, argument)
diff --git a/tests/tox_env/python/test_python_api.py b/tests/tox_env/python/test_python_api.py
index ed4801a93..4489d5f45 100644
--- a/tests/tox_env/python/test_python_api.py
+++ b/tests/tox_env/python/test_python_api.py
@@ -255,7 +255,7 @@ def test_python_hash_seed_from_env_and_disable(tox_project: ToxProjectCreator) -
 
 @pytest.mark.parametrize("in_ci", [True, False])
 def test_list_installed_deps(in_ci: bool, tox_project: ToxProjectCreator, mocker: MockerFixture) -> None:
-    mocker.patch("tox.session.cmd.run.common.is_ci", return_value=in_ci)
+    mocker.patch("tox.config.cli.parser.is_ci", return_value=in_ci)
     result = tox_project({"tox.ini": "[testenv]\nskip_install = true"}).run("r", "-e", "py")
     if in_ci:
         assert "pip==" in result.out
@@ -271,7 +271,7 @@ def test_list_installed_deps_explicit_cli(
     tox_project: ToxProjectCreator,
     mocker: MockerFixture,
 ) -> None:
-    mocker.patch("tox.session.cmd.run.common.is_ci", return_value=in_ci)
+    mocker.patch("tox.config.cli.parser.is_ci", return_value=in_ci)
     result = tox_project({"tox.ini": "[testenv]\nskip_install = true"}).run(list_deps, "r", "-e", "py")
     if list_deps == "--list-dependencies":
         assert "pip==" in result.out

EOF_114329324912
: '>>>>> Start Test Output'
pytest -rA
: '>>>>> End Test Output'
git checkout 380d2e21c08df30034372cd31f445f3da1f48cef tests/test_provision.py tests/tox_env/python/test_python_api.py
