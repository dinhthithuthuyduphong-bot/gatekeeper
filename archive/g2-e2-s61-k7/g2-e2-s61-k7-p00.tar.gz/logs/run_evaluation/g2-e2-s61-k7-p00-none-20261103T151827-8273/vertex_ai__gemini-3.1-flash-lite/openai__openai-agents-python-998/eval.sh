#!/bin/bash
set -uxo pipefail
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git checkout b09d37d8326c5d21760aaf10e9ff2eb8a01ebdaa tests/test_agent_config.py
git apply --verbose --reject - <<'EOF_114329324912'
diff --git a/tests/test_agent_config.py b/tests/test_agent_config.py
index a985fd60d..5b633b70b 100644
--- a/tests/test_agent_config.py
+++ b/tests/test_agent_config.py
@@ -2,6 +2,8 @@
 from pydantic import BaseModel
 
 from agents import Agent, AgentOutputSchema, Handoff, RunContextWrapper, handoff
+from agents.lifecycle import AgentHooksBase
+from agents.model_settings import ModelSettings
 from agents.run import AgentRunner
 
 
@@ -167,3 +169,58 @@ async def test_agent_final_output():
     assert schema.is_strict_json_schema() is True
     assert schema.json_schema() is not None
     assert not schema.is_plain_text()
+
+
+class TestAgentValidation:
+    """Essential validation tests for Agent __post_init__"""
+
+    def test_name_validation_critical_cases(self):
+        """Test name validation - the original issue that started this PR"""
+        # This was the original failing case that caused JSON serialization errors
+        with pytest.raises(TypeError, match="Agent name must be a string, got int"):
+            Agent(name=1)  # type: ignore
+
+        with pytest.raises(TypeError, match="Agent name must be a string, got NoneType"):
+            Agent(name=None)  # type: ignore
+
+    def test_tool_use_behavior_dict_validation(self):
+        """Test tool_use_behavior accepts StopAtTools dict - fixes existing test failures"""
+        # This test ensures the existing failing tests now pass
+        Agent(name="test", tool_use_behavior={"stop_at_tool_names": ["tool1"]})
+
+        # Invalid cases that should fail
+        with pytest.raises(TypeError, match="Agent tool_use_behavior must be"):
+            Agent(name="test", tool_use_behavior=123)  # type: ignore
+
+    def test_hooks_validation_python39_compatibility(self):
+        """Test hooks validation works with Python 3.9 - fixes generic type issues"""
+
+        class MockHooks(AgentHooksBase):
+            pass
+
+        # Valid case
+        Agent(name="test", hooks=MockHooks())  # type: ignore
+
+        # Invalid case
+        with pytest.raises(TypeError, match="Agent hooks must be an AgentHooks instance"):
+            Agent(name="test", hooks="invalid")  # type: ignore
+
+    def test_list_field_validation(self):
+        """Test critical list fields that commonly get wrong types"""
+        # These are the most common mistakes users make
+        with pytest.raises(TypeError, match="Agent tools must be a list"):
+            Agent(name="test", tools="not_a_list")  # type: ignore
+
+        with pytest.raises(TypeError, match="Agent handoffs must be a list"):
+            Agent(name="test", handoffs="not_a_list")  # type: ignore
+
+    def test_model_settings_validation(self):
+        """Test model_settings validation - prevents runtime errors"""
+        # Valid case
+        Agent(name="test", model_settings=ModelSettings())
+
+        # Invalid case that could cause runtime issues
+        with pytest.raises(
+            TypeError, match="Agent model_settings must be a ModelSettings instance"
+        ):
+            Agent(name="test", model_settings={})  # type: ignore

EOF_114329324912
: '>>>>> Start Test Output'
uv run pytest -rA
: '>>>>> End Test Output'
git checkout b09d37d8326c5d21760aaf10e9ff2eb8a01ebdaa tests/test_agent_config.py
