#!/bin/bash
set -uxo pipefail
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git checkout 7b0ad9795df5f9a49a585b6c2368a476c286c217 test/unit/module/jsonschema/test_validator.py
git apply --verbose --reject - <<'EOF_114329324912'
diff --git a/test/unit/module/jsonschema/test_validator.py b/test/unit/module/jsonschema/test_validator.py
index f981aadd58..863195472d 100644
--- a/test/unit/module/jsonschema/test_validator.py
+++ b/test/unit/module/jsonschema/test_validator.py
@@ -947,6 +947,28 @@ def test_validator(name, schema, instance, expected, validator):
                 )
             ],
         ),
+        (
+            "valid requiredOr",
+            {"requiredOr": ["foo", "bar"]},
+            {"foo": {}},
+            [],
+        ),
+        (
+            "valid requiredOr with wrong type",
+            {"requiredOr": ["foo", "bar"]},
+            [],
+            [],
+        ),
+        (
+            "invalid requiredOr with empty object",
+            {"requiredOr": ["foo", "bar"]},
+            {},
+            [
+                ValidationError(
+                    "One of ['foo', 'bar'] is a required property",
+                )
+            ],
+        ),
         (
             "valid requiredXor",
             {"requiredXor": ["foo", "bar"]},

EOF_114329324912
: '>>>>> Start Test Output'
pytest -m "not data" -rA
: '>>>>> End Test Output'
git checkout 7b0ad9795df5f9a49a585b6c2368a476c286c217 test/unit/module/jsonschema/test_validator.py
