#!/bin/bash
set -uxo pipefail
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git checkout 6534e00304d14defda4b88a54f3a1fb2019e862c tests/asyncapi/base/naming.py
git apply --verbose --reject - <<'EOF_114329324912'
diff --git a/tests/asyncapi/base/naming.py b/tests/asyncapi/base/naming.py
index 798a24b564..0c3fc9454c 100644
--- a/tests/asyncapi/base/naming.py
+++ b/tests/asyncapi/base/naming.py
@@ -90,6 +90,76 @@ async def handle_user_created(msg: str): ...
             "custom:Message:Payload"
         ]
 
+    def test_subscriber_naming_default(self):
+        broker = self.broker_class()
+
+        broker.subscriber("test")
+
+        schema = get_app_schema(FastStream(broker)).to_jsonable()
+
+        assert list(schema["channels"].keys()) == [
+            IsStr(regex=r"test[\w:]*:Subscriber")
+        ]
+
+        assert list(schema["components"]["messages"].keys()) == [
+            IsStr(regex=r"test[\w:]*:Subscriber:Message")
+        ]
+
+        for key, v in schema["components"]["schemas"].items():
+            assert key == "Subscriber:Message:Payload"
+            assert v == {"title": key}
+
+    def test_subscriber_naming_default_with_title(self):
+        broker = self.broker_class()
+
+        broker.subscriber("test", title="custom")
+
+        schema = get_app_schema(FastStream(broker)).to_jsonable()
+
+        assert list(schema["channels"].keys()) == ["custom"]
+
+        assert list(schema["components"]["messages"].keys()) == ["custom:Message"]
+
+        assert list(schema["components"]["schemas"].keys()) == [
+            "custom:Message:Payload"
+        ]
+
+        assert schema["components"]["schemas"]["custom:Message:Payload"] == {
+            "title": "custom:Message:Payload"
+        }
+
+    def test_multi_subscribers_naming_default(self):
+        broker = self.broker_class()
+
+        @broker.subscriber("test")
+        async def handle_user_created(msg: str): ...
+
+        broker.subscriber("test2")
+        broker.subscriber("test3")
+
+        schema = get_app_schema(FastStream(broker)).to_jsonable()
+
+        assert list(schema["channels"].keys()) == [
+            IsStr(regex=r"test[\w:]*:HandleUserCreated"),
+            IsStr(regex=r"test2[\w:]*:Subscriber"),
+            IsStr(regex=r"test3[\w:]*:Subscriber"),
+        ]
+
+        assert list(schema["components"]["messages"].keys()) == [
+            IsStr(regex=r"test[\w:]*:HandleUserCreated:Message"),
+            IsStr(regex=r"test2[\w:]*:Subscriber:Message"),
+            IsStr(regex=r"test3[\w:]*:Subscriber:Message"),
+        ]
+
+        assert list(schema["components"]["schemas"].keys()) == [
+            "HandleUserCreated:Message:Payload",
+            "Subscriber:Message:Payload",
+        ]
+
+        assert schema["components"]["schemas"]["Subscriber:Message:Payload"] == {
+            "title": "Subscriber:Message:Payload"
+        }
+
 
 class FilterNaming(BaseNaming):
     def test_subscriber_filter_base(self):

EOF_114329324912
: '>>>>> Start Test Output'
cat scripts/test.sh
coverage run -m pytest -rA -x --ff -m "(slow and (not nats and not kafka and not confluent and not rabbit and not redis)) or (not nats and not kafka and not confluent and not rabbit and not redis)"
: '>>>>> End Test Output'
git checkout 6534e00304d14defda4b88a54f3a1fb2019e862c tests/asyncapi/base/naming.py
