#!/bin/bash
set -uxo pipefail
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git checkout 6d886dc0fa8e0fa1d011e9332f609cee526c9bbd pvlib/tests/test_solarposition.py
git apply --verbose --reject - <<'EOF_114329324912'
diff --git a/pvlib/tests/test_solarposition.py b/pvlib/tests/test_solarposition.py
index 9a69673d6c..88093e05f9 100644
--- a/pvlib/tests/test_solarposition.py
+++ b/pvlib/tests/test_solarposition.py
@@ -8,6 +8,7 @@
 from .conftest import assert_frame_equal, assert_series_equal
 from numpy.testing import assert_allclose
 import pytest
+import pytz
 
 from pvlib.location import Location
 from pvlib import solarposition, spa
@@ -711,6 +712,38 @@ def test_hour_angle():
         solarposition._local_times_from_hours_since_midnight(times, hours)
 
 
+def test_hour_angle_with_tricky_timezones():
+    # GH 2132
+    # tests timezones that have a DST shift at midnight
+
+    eot = np.array([-3.935172, -4.117227, -4.026295, -4.026295])
+
+    longitude = 70.6693
+    times = pd.DatetimeIndex([
+        '2014-09-06 23:00:00',
+        '2014-09-07 00:00:00',
+        '2014-09-07 01:00:00',
+        '2014-09-07 02:00:00',
+    ]).tz_localize('America/Santiago', nonexistent='shift_forward')
+
+    with pytest.raises(pytz.exceptions.NonExistentTimeError):
+        times.normalize()
+
+    # should not raise `pytz.exceptions.NonExistentTimeError`
+    solarposition.hour_angle(times, longitude, eot)
+
+    longitude = 82.3666
+    times = pd.DatetimeIndex([
+        '2014-11-01 23:00:00',
+        '2014-11-02 00:00:00',
+        '2014-11-02 01:00:00',
+        '2014-11-02 02:00:00',
+    ]).tz_localize('America/Havana', ambiguous=[True, True, False, False])
+
+    with pytest.raises(pytz.exceptions.AmbiguousTimeError):
+        solarposition.hour_angle(times, longitude, eot)
+
+
 def test_sun_rise_set_transit_geometric(expected_rise_set_spa, golden_mst):
     """Test geometric calculations for sunrise, sunset, and transit times"""
     times = expected_rise_set_spa.index

EOF_114329324912
: '>>>>> Start Test Output'
pytest pvlib --ignore=pvlib/tests/iotools -rA
: '>>>>> End Test Output'
git checkout 6d886dc0fa8e0fa1d011e9332f609cee526c9bbd pvlib/tests/test_solarposition.py
