#!/bin/bash
set -uxo pipefail
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git checkout a1d4c7c10fe06f8a938de8f1145b6470cd56e618 test/unit/rules/functions/test_sub.py
git apply --verbose --reject - <<'EOF_114329324912'
diff --git a/test/unit/rules/functions/test_sub.py b/test/unit/rules/functions/test_sub.py
index ff67ed210f..8162c4f184 100644
--- a/test/unit/rules/functions/test_sub.py
+++ b/test/unit/rules/functions/test_sub.py
@@ -156,6 +156,12 @@ def context(cfn):
             {"type": "string"},
             [],
         ),
+        (
+            "Valid Fn::Sub with an integer parameter",
+            {"Fn::Sub": ["${Foo}", {"Foo": 1}]},
+            {"type": "string"},
+            [],
+        ),
         (
             "Invalid Fn::Sub with a too to many elements",
             {"Fn::Sub": ["${foo}", {"foo": "bar"}, {}]},

EOF_114329324912
: '>>>>> Start Test Output'
pytest -rA
: '>>>>> End Test Output'
git checkout a1d4c7c10fe06f8a938de8f1145b6470cd56e618 test/unit/rules/functions/test_sub.py
