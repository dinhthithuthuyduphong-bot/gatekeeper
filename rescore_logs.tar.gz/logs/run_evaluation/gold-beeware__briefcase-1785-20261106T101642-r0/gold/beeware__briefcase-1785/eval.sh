#!/bin/bash
set -uxo pipefail
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git checkout 105823765d607dc32e153fc69495c9aa10eedb0b tests/integrations/docker/test_Docker__verify.py
git apply --verbose --reject - <<'EOF_114329324912'
diff --git a/tests/integrations/docker/test_Docker__verify.py b/tests/integrations/docker/test_Docker__verify.py
index ad65382a3..6aa8c4aae 100644
--- a/tests/integrations/docker/test_Docker__verify.py
+++ b/tests/integrations/docker/test_Docker__verify.py
@@ -65,11 +65,21 @@ def test_docker_install_url(host_os):
     assert host_os in Docker.DOCKER_INSTALL_URL
 
 
-def test_docker_exists(mock_tools, user_mapping_run_calls, capsys):
+@pytest.mark.parametrize(
+    "version_output",
+    [
+        VALID_DOCKER_VERSION,
+        # Docker version format on Ubuntu
+        "Docker version 26.1.1, build 4cf5afa",
+        # Docker version format on OpenSUSE Tumbleweed
+        "Docker version 26.1.0-ce, build c8af8ebe4a89",
+    ],
+)
+def test_docker_exists(mock_tools, user_mapping_run_calls, version_output, capsys):
     """If docker exists, the Docker wrapper is returned."""
     # Mock the return value of Docker Version
     mock_tools.subprocess.check_output.side_effect = [
-        VALID_DOCKER_VERSION,
+        version_output,
         VALID_DOCKER_INFO,
         VALID_BUILDX_VERSION,
         VALID_USER_MAPPING_IMAGE_CACHE,

EOF_114329324912
: '>>>>> Start Test Output'
pytest -rA
: '>>>>> End Test Output'
git checkout 105823765d607dc32e153fc69495c9aa10eedb0b tests/integrations/docker/test_Docker__verify.py
