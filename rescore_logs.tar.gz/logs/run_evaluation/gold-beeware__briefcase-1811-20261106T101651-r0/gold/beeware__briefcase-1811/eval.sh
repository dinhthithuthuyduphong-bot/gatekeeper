#!/bin/bash
set -uxo pipefail
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git checkout 92493e36a5bb8efe4653db5295a48841cc92ff4d tests/integrations/cookiecutter/test_TOMLEscape.py
git apply --verbose --reject - <<'EOF_114329324912'
diff --git a/tests/integrations/cookiecutter/test_TOMLEscape.py b/tests/integrations/cookiecutter/test_TOMLEscape.py
index e80adc335..a3e6d05f5 100644
--- a/tests/integrations/cookiecutter/test_TOMLEscape.py
+++ b/tests/integrations/cookiecutter/test_TOMLEscape.py
@@ -10,7 +10,7 @@
     [
         # Single digit minor
         ("Hello World", "Hello World"),
-        ('Hello " World', 'Hello " World'),
+        ('Hello " World', 'Hello \\" World'),
         ("Hello \\ World", "Hello \\\\ World"),
     ],
 )

EOF_114329324912
: '>>>>> Start Test Output'
pytest -rA
: '>>>>> End Test Output'
git checkout 92493e36a5bb8efe4653db5295a48841cc92ff4d tests/integrations/cookiecutter/test_TOMLEscape.py
