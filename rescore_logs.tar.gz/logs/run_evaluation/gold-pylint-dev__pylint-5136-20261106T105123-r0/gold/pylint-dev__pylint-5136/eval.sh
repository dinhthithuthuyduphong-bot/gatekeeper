#!/bin/bash
set -uxo pipefail
source /opt/miniconda3/bin/activate
conda activate testbed
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git status
git show
git -c core.fileMode=false diff 3a5a91c0fa0761555aed2cb03270e2bb63b400fb
source /opt/miniconda3/bin/activate
conda activate testbed
python -m pip install -e .
git checkout 3a5a91c0fa0761555aed2cb03270e2bb63b400fb tests/test_regr.py
git apply -v - <<'EOF_114329324912'
diff --git a/tests/test_regr.py b/tests/test_regr.py
--- a/tests/test_regr.py
+++ b/tests/test_regr.py
@@ -129,7 +129,6 @@ def test_pylint_config_attr() -> None:
     expect = [
         "OptionsManagerMixIn",
         "object",
-        "MessagesHandlerMixIn",
         "ReportsHandlerMixIn",
         "BaseTokenChecker",
         "BaseChecker",

EOF_114329324912
: '>>>>> Start Test Output'
pytest -rA tests/test_regr.py
SWEBENCH_TEST_EXIT_CODE=$?
: '>>>>> End Test Output'
echo ">>>>> Test Exit Code: $SWEBENCH_TEST_EXIT_CODE"
git checkout 3a5a91c0fa0761555aed2cb03270e2bb63b400fb tests/test_regr.py
