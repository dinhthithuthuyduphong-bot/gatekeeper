#!/bin/bash
set -uxo pipefail
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git checkout ced35bd28540ea0630a759b336054b5e4779f765 tests/test_connectors/test_postgresql.py
git apply --verbose --reject - <<'EOF_114329324912'
diff --git a/tests/test_connectors/test_postgresql.py b/tests/test_connectors/test_postgresql.py
index ed3f912a..e3551087 100644
--- a/tests/test_connectors/test_postgresql.py
+++ b/tests/test_connectors/test_postgresql.py
@@ -122,9 +122,7 @@ def test_restore_dump_user(self, mock_dump_cmd, mock_restore_cmd):
         # With
         self.connector.settings["USER"] = "foo"
         self.connector.restore_dump(dump)
-        self.assertIn(
-            "postgresql://foo@hostname/dbname", mock_restore_cmd.call_args[0][0]
-        )
+        self.assertIn("postgresql://foo@hostname/dbname", mock_restore_cmd.call_args[0][0])
 
     def test_create_dump_schema(self, mock_dump_cmd):
         # Without
@@ -220,34 +218,35 @@ def test_create_dump_drop(self, mock_dump_cmd):
 
     def test_create_dump_if_exists(self, mock_run_command):
         dump = self.connector.create_dump()
-        # Test explicit if_exists=True behavior
-        self.connector.if_exists = True
-        self.connector.drop = False  # Disable automatic --if-exists from --clean
+
+        # Default now includes --if-exists even without --clean
+        self.connector.drop = False
         self.connector.restore_dump(dump)
         cmd_args = mock_run_command.call_args[0][0]
         self.assertNotIn(" --clean", cmd_args)
         self.assertIn(" --if-exists", cmd_args)
-        
-        # Test that if_exists=False with drop=False means no --if-exists
+
+        # Disabling if_exists explicitly should remove the flag (when drop=False)
         self.connector.if_exists = False
         self.connector.drop = False
         self.connector.restore_dump(dump)
         cmd_args = mock_run_command.call_args[0][0]
         self.assertNotIn(" --clean", cmd_args)
         self.assertNotIn(" --if-exists", cmd_args)
-    
+
     def test_clean_automatically_enables_if_exists(self, mock_run_command):
         """Test that --if-exists is automatically added when using --clean to prevent identity column errors."""
         dump = self.connector.create_dump()
-        # When drop=True (which adds --clean), --if-exists should be automatically added
+
+        # When drop=True (which adds --clean), --if-exists should be automatically added even if disabled
         self.connector.drop = True
         self.connector.if_exists = False  # Explicitly set to False
         self.connector.restore_dump(dump)
         cmd_args = mock_run_command.call_args[0][0]
         self.assertIn(" --clean", cmd_args)
         self.assertIn(" --if-exists", cmd_args)
-        
-        # When drop=False, --if-exists should not be added automatically
+
+        # When drop=False and if_exists=False, --if-exists should not be added
         self.connector.drop = False
         self.connector.if_exists = False
         self.connector.restore_dump(dump)
@@ -360,9 +359,7 @@ def test_restore_dump(self, mock_dump_cmd, mock_restore_cmd):
     def test_enable_postgis(self, mock_dump_cmd):
         self.connector.settings["ADMIN_USER"] = "foo"
         self.connector._enable_postgis()
-        self.assertIn(
-            '"CREATE EXTENSION IF NOT EXISTS postgis;"', mock_dump_cmd.call_args[0][0]
-        )
+        self.assertIn('"CREATE EXTENSION IF NOT EXISTS postgis;"', mock_dump_cmd.call_args[0][0])
         self.assertIn("--username=foo", mock_dump_cmd.call_args[0][0])
 
     def test_enable_postgis_host(self, mock_dump_cmd):

EOF_114329324912
: '>>>>> Start Test Output'
pytest -rA
: '>>>>> End Test Output'
git checkout ced35bd28540ea0630a759b336054b5e4779f765 tests/test_connectors/test_postgresql.py
