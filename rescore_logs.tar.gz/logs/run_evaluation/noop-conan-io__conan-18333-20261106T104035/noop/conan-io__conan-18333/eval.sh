#!/bin/bash
set -uxo pipefail
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git checkout 86e2822989b555778505c847fe92cc11e04cb853 test/unittests/client/toolchain/autotools/autotools_toolchain_test.py test/unittests/tools/gnu/test_gnutoolchain.py
git apply --verbose --reject - <<'EOF_114329324912'
diff --git a/test/unittests/client/toolchain/autotools/autotools_toolchain_test.py b/test/unittests/client/toolchain/autotools/autotools_toolchain_test.py
index 0879043d03c..7576aa6dd62 100644
--- a/test/unittests/client/toolchain/autotools/autotools_toolchain_test.py
+++ b/test/unittests/client/toolchain/autotools/autotools_toolchain_test.py
@@ -605,3 +605,23 @@ def test_conf_compiler_executable():
     be = AutotoolsToolchain(conanfile)
     env = be.vars()
     assert "/c/my/path/myg++" == env["CXX"]
+
+
+def test_autotools_toolchain_conf_extra_configure_args():
+    """Validate that tools.gnu:extra_configure_args are passed to configure command only.
+
+       The configure args should be passed as list only.
+    """
+    f = temp_folder()
+    os.chdir(f)
+    conanfile = ConanFileMock()
+    conanfile.settings = MockSettings({"os": "Linux", "arch": "x86_64"})
+    conanfile.conf = Conf()
+    conanfile.conf.define("tools.gnu:extra_configure_args", ["--foo", "--bar"])
+
+    be = AutotoolsToolchain(conanfile)
+    be.generate_args()
+    obj = load_toolchain_args()
+    assert "--foo --bar" in obj["configure_args"]
+    # make sure it does not forward to make
+    assert "--foo" not in obj["make_args"]
diff --git a/test/unittests/tools/gnu/test_gnutoolchain.py b/test/unittests/tools/gnu/test_gnutoolchain.py
index a0e545d8b3d..650179cbf34 100644
--- a/test/unittests/tools/gnu/test_gnutoolchain.py
+++ b/test/unittests/tools/gnu/test_gnutoolchain.py
@@ -235,3 +235,18 @@ def test_crossbuild_to_android(build_env_mock):
     assert gnutc.triplets_info["host"]["triplet"] == "aarch64-linux-android"
     assert env_vars["LD"] == os.path.join(ndk_bin, "ld")  # exists
     assert env_vars["STRIP"] == os.path.join(ndk_bin, "llvm-strip")  # does not exist but appears
+
+
+def test_gnu_toolchain_conf_extra_configure_args():
+    """ Validate that tools.gnu:extra_configure_args are passed to the configure_args when
+        building with GnuToolchain.
+        The configure args should be passed as a list-like object.
+    """
+    conanfile = ConanFileMock()
+    conanfile.settings = MockSettings({"os": "Linux", "arch": "x86_64"})
+    conanfile.conf = Conf()
+    conanfile.conf.define("tools.gnu:extra_configure_args", ["--foo", "--bar"])
+
+    tc = GnuToolchain(conanfile)
+    assert tc.configure_args["--foo"] is None
+    assert tc.configure_args["--bar"] is None

EOF_114329324912
: '>>>>> Start Test Output'
pytest -rA
pytest -v -rA
pytest -v -rA --tb=short --maxfail=100 test/unittests
: '>>>>> End Test Output'
git checkout 86e2822989b555778505c847fe92cc11e04cb853 test/unittests/client/toolchain/autotools/autotools_toolchain_test.py test/unittests/tools/gnu/test_gnutoolchain.py
