#!/bin/bash
set -uxo pipefail
cd /testbed
git config --global --add safe.directory /testbed
cd /testbed
git checkout cacaa905665a9a3360b23ea6e91d6ddfa1a42fb6 tests/test_cors_middleware.py
git apply --verbose --reject - <<'EOF_114329324912'
diff --git a/tests/test_cors_middleware.py b/tests/test_cors_middleware.py
index 9aff6abf6..df1a0d589 100644
--- a/tests/test_cors_middleware.py
+++ b/tests/test_cors_middleware.py
@@ -161,6 +161,32 @@ def my_sink(req, resp):
             assert 'Access-Control-Expose-Headers' not in result.headers
             assert 'Access-Control-Allow-Origin' not in result.headers
 
+    @pytest.mark.parametrize('include_request_private_network', (True, False))
+    def test_disabled_cors_private_network(
+        self, cors_client, include_request_private_network
+    ):
+        # default scenario for cors middleware, where
+        # allow private network is off by default
+
+        cors_client.app.add_route('/', CORSHeaderResource())
+
+        headers = (
+            ('Origin', 'localhost'),
+            ('Access-Control-Request-Method', 'GET'),
+        )
+
+        if include_request_private_network:
+            headers = (
+                *headers,
+                ('Access-Control-Request-Private-Network', 'true'),
+            )
+
+        result = cors_client.simulate_options('/', headers=headers)
+
+        h = result.headers
+
+        assert 'Access-Control-Allow-Private-Network' not in h
+
 
 @pytest.fixture(scope='function')
 def make_cors_client(asgi, util):
@@ -293,3 +319,19 @@ def test_expose_headers(self, make_cors_client, attr, exp):
         assert res.headers['Access-Control-Expose-Headers'] == exp
         h = dict(res.headers.lower_items()).keys()
         assert 'Access-Control-Allow-Credentials'.lower() not in h
+
+    def test_enabled_cors_private_network_headers(self, make_cors_client):
+        client = make_cors_client(falcon.CORSMiddleware(allow_private_network=True))
+
+        client.app.add_route('/', CORSHeaderResource())
+
+        res = client.simulate_options(
+            '/',
+            headers=(
+                ('Origin', 'localhost'),
+                ('Access-Control-Request-Method', 'GET'),
+                ('Access-Control-Request-Private-Network', 'true'),
+            ),
+        )
+
+        assert res.headers['Access-Control-Allow-Private-Network'] == 'true'

EOF_114329324912
: '>>>>> Start Test Output'
pytest -rA
: '>>>>> End Test Output'
git checkout cacaa905665a9a3360b23ea6e91d6ddfa1a42fb6 tests/test_cors_middleware.py
